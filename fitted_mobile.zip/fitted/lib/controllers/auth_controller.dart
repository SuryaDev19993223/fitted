import 'dart:convert';
import 'dart:io';
import 'package:fitted/utils/constants.dart';
import 'package:http/http.dart' as http;


class AuthController {

  Future<String> loginRepo(String email, String password) async {
    String responseData;
    var data ;
    final String url = "/login" ;
    final client = new http.Client();
    final response = await client.post(
      Uri.parse(Constants.SERVER_URL + url),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
      body: json.encode({"email": email, "password": password}),
    );
    print(response.body);
    if (response.statusCode == 200) {
      data = json.decode(response.body);
      data['code'] = response.statusCode;
      responseData = json.encode(data);
    } else {
      // throw new Exception(response.body);
      data = {};
      data['code']  = response.statusCode;
      data['message']  = response.body;
      responseData = json.encode(data);
    }
    return responseData;
  }

  Future<String> signupRepo(String name, String email, String password) async {
    String responseData;
    var data = {};
    final String url = "/register" ;
    final client = new http.Client();
    final response = await client.post(
      Uri.parse(Constants.SERVER_URL + url),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
      body: json.encode({"name": name ,"email": email, "password": password, "role": 1}),
    );
    if (response.statusCode == 200) {
      data['code'] = response.statusCode;
      responseData = json.encode(data);
    } else {
      // throw new Exception(response.body);
      data['code']  = response.statusCode;
      data['message']  = response.body;
      responseData = json.encode(data);
    }
    return responseData;
  }

  Future<String> socialLogin(Map data) async {
    String responseData;
    var data = {};
    final String url = "/socialLogin" ;
    final client = new http.Client();
    final response = await client.post(
      Uri.parse(Constants.SERVER_URL + url),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
      body: json.encode({"social": data["social"] ,"social_id": data["social_id"], "email": data["email"], "username": "abc"}),
    );
    if (response.statusCode == 200) {
      data['code'] = response.statusCode;
      responseData = json.encode(data);
    } else {
      // throw new Exception(response.body);
      data['code']  = response.statusCode;
      data['message']  = response.body;
      responseData = json.encode(data);
    }
    return responseData;
  }


  Future<String> signOutRepo(String userId) async {
    String responseData;
    var data = {};
    final String url = "/v1/logout/" + userId ;
    final client = new http.Client();
    final response = await client.get(
      Uri.parse(Constants.SERVER_URL + url),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
    );
    if (response.statusCode == 200) {
      data['code'] = response.statusCode;
      responseData = json.encode(data);
    } else {
      data['code']  = response.statusCode;
      responseData = json.encode(data);
    }
    return responseData;
  }

}