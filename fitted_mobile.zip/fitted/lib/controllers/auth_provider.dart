// ignore_for_file: use_build_context_synchronously, non_constant_identifier_names

import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:provider/provider.dart';
class AuthProvider with ChangeNotifier {
  // final AuthRepo authRepo;
  //
  // AuthProvider({required this.authRepo});

  // for slider
  int currentPage = 0;

  changeCurrentPage(int index) {
    currentPage = index;
    notifyListeners();
  }



  bool _isLoading = false;

  bool get isLoading => _isLoading;
  bool isToggle = true;
  bool isToggle1 = true;
  bool isToggle2 = true;
  int tapIndex = 0;
  String tokenResetPassword = '';

  toggleDone({int? index}) {
    if (index == 0) {
      isToggle = !isToggle;
    } else if (index == 1) {
      isToggle1 = !isToggle1;
    } else if (index == 2) {
      isToggle2 = !isToggle2;
    }
    notifyListeners();
  }

  // for Sign in Section
  showLoader(bool value, {bool isInit = false}) {
    _isLoading = value;
    if (!isInit) notifyListeners();
  }

}
