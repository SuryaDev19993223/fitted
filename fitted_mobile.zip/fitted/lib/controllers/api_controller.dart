import 'dart:convert';
import 'dart:io';
import 'package:http/http.dart' as http;
import 'package:fitted/utils/constants.dart';
import 'package:shared_preferences/shared_preferences.dart';

class APIController {
  Future<String> cloudAuthPost() async {
    String responseData;
    var data ;
    final sharedPreferences = await SharedPreferences.getInstance();
    final client = new http.Client();
    final response = await client.post(
      Uri.parse('https://tozi.cafilab.com/open/v2/auth/token/'),
      headers: {HttpHeaders.contentTypeHeader: 'application/json'},
      body: json.encode(
          {
            "appKey": Constants.appKey,
            "appSecret": Constants.appSecret,
            "expireMinutes": Constants.expireMinutes
          }
      ),
    );
    if (response.statusCode == 200) {
      data = json.decode(response.body);
      data['code'] = response.statusCode;
      responseData = json.encode(data);
      var cloudTokenTemp = data['data']['token'];
      var cloudToken = cloudTokenTemp.toString().split(' ');
      sharedPreferences.setString('cloud_token', cloudToken[1] );
    } else {
      // throw new Exception(response.body);
      data = {};
      data['code']  = response.statusCode;
      responseData = json.encode(data);
    }
    return responseData;
  }

  Future<String> cloudPhotoPost(int photoType, String photoSrcBase64) async {
    String responseData;
    var data ;
    final sharedPreferences = await SharedPreferences.getInstance();
    var cloudToken = sharedPreferences.getString('cloud_token');
    final client = new http.Client();
    final response = await client.post(
      Uri.parse('https://tozi.cafilab.com/open/v2/measure/photo/process'),
      headers: {HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer ' + cloudToken!
      },
      body: json.encode(
          {
            "photoType": photoType,
            "photoSrc": photoSrcBase64,
            "lang": ""
          }
      ),
    );
    if (response.statusCode == 200) {
      data = json.decode(response.body);
      data['code'] = response.statusCode;
      responseData = json.encode(data);
    } else {
      // throw new Exception(response.body);
      data = {};
      data['code']  = response.statusCode;
      responseData = json.encode(data);
    }
    return responseData;
  }

  Future<String> cloudProfilePost(String frontTicket, String sideTicket) async {
    String responseData;
    var data ;
    final sharedPreferences = await SharedPreferences.getInstance();
    var cloudToken = sharedPreferences.getString('cloud_token');
    var measurement = json.decode(sharedPreferences.getString('measurement')!);
    var height = int.parse(measurement['height'].toString());
    var weight = int.parse(measurement['weight'].toString());
    var gender = int.parse(measurement['gender'].toString());
    var body = {
      "frontTicket": frontTicket,
      "sideTicket": sideTicket,
      "userGender": gender,
      "userHeight": height,
      "userWeight": weight,
      "dataType": 0,
      "measureName": "test photo",
      "lang": ""
    };
    print(body);
    final client = new http.Client();
    final response = await client.post(
      Uri.parse('https://tozi.cafilab.com/open/v2/measure/photo/data'),
      headers: {HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer ' + cloudToken!
      },
      body: json.encode(body),
    );
    if (response.statusCode == 200) {
      data = json.decode(response.body);
      data['code'] = response.statusCode;
      responseData = json.encode(data);
    } else {
      // throw new Exception(response.body);
      data = {};
      data['code']  = response.statusCode;
      responseData = json.encode(data);
    }
    return responseData;
  }


  Future<String> cloudSizePost(String measureId, dynamic frontProfileBody, dynamic sideProfileBody) async {
    String responseData;
    var data ;
    final sharedPreferences = await SharedPreferences.getInstance();
    var cloudToken = sharedPreferences.getString('cloud_token');
    final client = new http.Client();
    final response = await client.post(
      Uri.parse('https://tozi.cafilab.com/open/v2/measure/profile/data'),
      headers: {HttpHeaders.contentTypeHeader: 'application/json',
        HttpHeaders.authorizationHeader: 'Bearer ' + cloudToken!
      },
      body: json.encode(
          {
            "measureId": measureId,
            "dataType": 1,
            "lang": "",
            "frontProfileBody": frontProfileBody,
            "sideProfileBody": sideProfileBody
          }
      ),
    );
    if (response.statusCode == 200) {
      data = json.decode(response.body);
      data['code'] = response.statusCode;
      responseData = json.encode(data);
      sharedPreferences.setString('calculatedMeasure', json.encode(data['data']['sizes']));
    } else {
      // throw new Exception(response.body);
      data = {};
      data['code']  = response.statusCode;
      responseData = json.encode(data);
    }
    return responseData;
  }

}