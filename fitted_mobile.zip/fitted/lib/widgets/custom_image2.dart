import 'package:flutter/material.dart';
// ignore_for_file: must_be_immutable
class CustomImage2 extends StatelessWidget {
  String? img;
  double? scale;
  Color? color;
  CustomImage2({this.img, this.scale,this.color, super.key});

  @override
  Widget build(BuildContext context) {
    return Image.asset(img ?? "assets/icons/ic_app.png", scale: scale ?? 3,color: color,);
  }
}
