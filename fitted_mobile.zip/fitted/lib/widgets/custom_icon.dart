import 'package:flutter/material.dart';
// ignore_for_file: must_be_immutable
class CustomIcon extends StatelessWidget {
  CustomIcon({this.icon, this.height, this.color, super.key});
  String? icon;
  double? height;
  Color? color;

  @override
  Widget build(BuildContext context) {
    return Image.asset(icon ?? "", height: height ?? 20, color: color ?? Colors.transparent);
  }
}
