import 'package:flutter/material.dart';

// ignore_for_file: must_be_immutable
class CustomInkWell extends StatelessWidget {
  CustomInkWell(
      {this.onTap, this.onLongPress, this.onHover, this.child, super.key});
  Function? onTap;
  Function? onLongPress;
  Function(bool)? onHover;
  Widget? child;

  @override
  Widget build(BuildContext context) {
    return InkWell(
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      onHover: (val) {
        onHover!;
      },
      onTap: () {
        FocusScope.of(context).requestFocus(FocusNode());
        if (onTap != null) {
          onTap!();
        }
      },
      onLongPress: () {
        if (onLongPress != null) {
          FocusScope.of(context).requestFocus(FocusNode());
          onLongPress!();
        }
      },
      child: child,
    );
  }
}
