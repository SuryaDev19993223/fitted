class Constants {
  static const appKey = 'QAgb2OUUNZ';
  static const appSecret = '3QnsH8LoJx';
  static const expireMinutes = 1000;
  // static const SERVER_URL = 'http://192.168.145.105/fittedAdmin/public/api';
  static const SERVER_URL = 'https://app.thefitted.co/public/api';
  // static const SERVER_URL = 'http://localhost/fittedAdmin/public/api';
}