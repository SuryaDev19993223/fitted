import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'intl/messages_all.dart';

class S {
  S();

  static S? current;

  static const AppLocalizationDelegate delegate =
  AppLocalizationDelegate();

  static Future<S> load(Locale locale) {
    final name = (locale.countryCode?.isEmpty ?? false) ? locale.languageCode : locale.toString();
    final localeName = Intl.canonicalizedLocale(name);
    return initializeMessages(localeName).then((_) {
      Intl.defaultLocale = localeName;
      S.current = S();
      return S();
    });
  }


  static S? of(BuildContext context) {
    return Localizations.of<S>(context, S);
  }

  static setLocale(int index) {
    var localeTH ;
    if(index == 0) {
      localeTH = const Locale('en');
    } else {
      localeTH = const Locale('fi');
    }
    delegate.load(localeTH);
  }

  String get language {
    return Intl.message(
      'Language',
      name: 'language',
      desc: '',
      args: [],
    );
  }

  String get english {
    return Intl.message(
      'English',
      name: 'english',
      desc: '',
      args: [],
    );
  }

  String get finnish {
    return Intl.message(
      'Finnish',
      name: 'finnish',
      desc: '',
      args: [],
    );
  }

  String get race_time_predictor {
    return Intl.message(
      'Race Time Predictor',
      name: 'race_time_predictor',
      desc: '',
      args: [],
    );
  }

  String get previous_race_information {
    return Intl.message(
      'Previous Race Information',
      name: 'previous_race_information',
      desc: '',
      args: [],
    );
  }

  String get distance {
    return Intl.message(
      'Distance',
      name: 'distance',
      desc: '',
      args: [],
    );
  }


  String get time {
    return Intl.message(
      'Time',
      name: 'time',
      desc: '',
      args: [],
    );
  }


  String get done {
    return Intl.message(
      'Done',
      name: 'done',
      desc: '',
      args: [],
    );
  }

  String get predict {
    return Intl.message(
      'Predict',
      name: 'predict',
      desc: '',
      args: [],
    );
  }
  String get metric {
    return Intl.message(
      'Metric',
      name: 'metric',
      desc: '',
      args: [],
    );
  }
  String get mile {
    return Intl.message(
      'Mile',
      name: 'mile',
      desc: '',
      args: [],
    );
  }

  String get finish_time {
    return Intl.message(
      'Finish Time',
      name: 'finish_time',
      desc: '',
      args: [],
    );
  }


  String get pace {
    return Intl.message(
      'Pace',
      name: 'pace',
      desc: '',
      args: [],
    );
  }

  String get select_language {
    return Intl.message(
      'Pace',
      name: 'select_language',
      desc: '',
      args: [],
    );
  }
  String get prediction_formula {
    return Intl.message(
      'Pace',
      name: 'prediction_formula',
      desc: '',
      args: [],
    );
  }
  String get metric_system {
    return Intl.message(
      'Pace',
      name: 'metric_system',
      desc: '',
      args: [],
    );
  }
  String get predicted_races {
    return Intl.message(
      'Pace',
      name: 'predicted_races',
      desc: '',
      args: [],
    );
  }
  String get settings {
    return Intl.message(
      'Pace',
      name: 'settings',
      desc: '',
      args: [],
    );
  }
  String get about_us {
    return Intl.message(
      'Pace',
      name: 'about_us',
      desc: '',
      args: [],
    );
  }
  String get sentance1 {
    return Intl.message(
      'Pace',
      name: 'sentance1',
      desc: '',
      args: [],
    );
  }
  String get sentance2 {
    return Intl.message(
      'Pace',
      name: 'sentance2',
      desc: '',
      args: [],
    );
  }
  String get sentance3 {
    return Intl.message(
      'Pace',
      name: 'sentance3',
      desc: '',
      args: [],
    );
  }
  String get sentance4 {
    return Intl.message(
      'Pace',
      name: 'sentance4',
      desc: '',
      args: [],
    );
  }
  String get your_name {
    return Intl.message(
      'Pace',
      name: 'your_name',
      desc: '',
      args: [],
    );
  }
  String get your_email {
    return Intl.message(
      'Pace',
      name: 'your_email',
      desc: '',
      args: [],
    );
  }String get message {
    return Intl.message(
      'Pace',
      name: 'message',
      desc: '',
      args: [],
    );
  }
  String get submit {
    return Intl.message(
      'Pace',
      name: 'submit',
      desc: '',
      args: [],
    );
  }

  String get height {
    return Intl.message(
      'Height',
      name: 'height',
      desc: '',
      args: [],
    );
  }

  String get centimeters {
    return Intl.message(
      'Centimeters',
      name: 'centimeters',
      desc: '',
      args: [],
    );
  }

  String get weight {
    return Intl.message(
      'Weight',
      name: 'weight',
      desc: '',
      args: [],
    );
  }

  String get kilograms {
    return Intl.message(
      'Kilograms',
      name: 'kilograms',
      desc: '',
      args: [],
    );
  }

  String get compute {
    return Intl.message(
      'Compute',
      name: 'compute',
      desc: '',
      args: [],
    );
  }

  String get your {
    return Intl.message(
      'Your',
      name: 'your',
      desc: '',
      args: [],
    );
  }

  String get categories {
    return Intl.message(
      'Categories',
      name: 'categories',
      desc: '',
      args: [],
    );
  }

  String get body_mass_index {
    return Intl.message(
      'Body Mass Index',
      name: 'body_mass_index',
      desc: '',
      args: [],
    );
  }

  String get under_weight {
    return Intl.message(
      'Underweight',
      name: 'under_weight',
      desc: '',
      args: [],
    );
  }

  String get normal_weight {
    return Intl.message(
      'Normal weight',
      name: 'normal_weight',
      desc: '',
      args: [],
    );
  }

  String get over_weight {
    return Intl.message(
      'Overweight',
      name: 'over_weight',
      desc: '',
      args: [],
    );
  }

  String get obesity {
    return Intl.message(
      'Obesity',
      name: 'obesity',
      desc: '',
      args: [],
    );
  }

  String get greater {
    return Intl.message(
      'greater',
      name: 'greater',
      desc: '',
      args: [],
    );
  }

  String get of_text {
    return Intl.message(
      'of',
      name: 'of_text',
      desc: '',
      args: [],
    );
  }

  String get or {
    return Intl.message(
      'or',
      name: 'or',
      desc: '',
      args: [],
    );
  }

  String get bmiText {
    return Intl.message(
      'BMI of 30 or greater',
      name: 'bmiText',
      desc: '',
      args: [],
    );
  }
  String get bmi_categories_text {
      return Intl.message(
        'BMI of 30 or greater',
        name: 'bmi_categories_text',
        desc: '',
        args: [],
      );
    }

}

class AppLocalizationDelegate extends LocalizationsDelegate<S> {
  const AppLocalizationDelegate();

  List<Locale> get supportedLocales {
    return const <Locale>[
      Locale.fromSubtags(languageCode: 'en'),
      Locale.fromSubtags(languageCode: 'fi'),
    ];
  }

  @override
  bool isSupported(Locale locale) => _isSupported(locale);
  @override
  Future<S> load(Locale locale) => S.load(locale);
  @override
  bool shouldReload(AppLocalizationDelegate old) => false;

  bool _isSupported(Locale locale) {
    if (locale != null) {
      for (var supportedLocale in supportedLocales) {
        if (supportedLocale.languageCode == locale.languageCode) {
          return true;
        }
      }
    }
    return false;
  }
}