import 'dart:io';

import 'package:camera/camera.dart';
import 'package:flutter/material.dart';

late List<CameraDescription> _cameras;

class CameraApp extends StatefulWidget {
  /// Default Constructor
  const CameraApp({super.key});

  @override
  State<CameraApp> createState() => _CameraAppState();
}

class _CameraAppState extends State<CameraApp> {
  // late CameraController controller;

  List<CameraDescription>? cameras; //list out the camera available
  CameraController? controller; //controller for camera
  XFile? image;

  @override
  void initState() {
    loadCamera();
    super.initState();
  }

  loadCamera() async {
    cameras = await availableCameras();
    if(cameras != null){
      controller = CameraController(cameras![0], ResolutionPreset.max);
      //cameras[0] = first camera, change to 1 to another camera

      controller!.initialize().then((_) {
        if (!mounted) {
          return;
        }
        setState(() {});
      });
    }else{
      print("NO any camera found");
    }
  }


  @override
  Widget build(BuildContext context) {

    return  Scaffold(
      appBar: AppBar(
        title: Text("Live Camera Preview"),
        backgroundColor: Colors.redAccent,
      ),
      body: Stack(
        children: [
          CameraPreview(controller!),
          Container( //show captured image
              padding: EdgeInsets.all(30),
              child: Image.asset('assets/images/silhouette_front_overlay.png')
            //display captured image
          )
        ],
      ),

      // floatingActionButton: FloatingActionButton(
      //   onPressed: () async{
      //     print("DDDDDDDDDDDD");
      //     try {
      //       if(controller != null){ //check if contrller is not null
      //         if(controller!.value.isInitialized){ //check if controller is initialized
      //           image = await controller!.takePicture(); //capture image
      //           setState(() {
      //             //update UI
      //           });
      //         }
      //       }
      //     } catch (e) {
      //       print(e); //show error
      //     }
      //   },
      //   child: Icon(Icons.camera),
      // ),

    );
  }
}

