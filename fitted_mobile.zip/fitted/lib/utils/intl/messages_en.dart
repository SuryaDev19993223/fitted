// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a en locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'en';

  static m0(id) => "Order: #${id} has been canceled";

  static m1(productName) => "The ${productName} was removed from your cart";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static _notInlinedMessages(_) => <String, Function> {
    "language" : MessageLookupByLibrary.simpleMessage("English Language"),
    "race_time_predictor" : MessageLookupByLibrary.simpleMessage("Race Time Predictor"),
    "previous_race_information" : MessageLookupByLibrary.simpleMessage("Previous Race Information"),
    "distance" : MessageLookupByLibrary.simpleMessage("Distance"),
    "time" : MessageLookupByLibrary.simpleMessage("Time"),
    "done" : MessageLookupByLibrary.simpleMessage("Done"),
    "predict" : MessageLookupByLibrary.simpleMessage("Predict"),
    "finish_time" : MessageLookupByLibrary.simpleMessage("Finish Time"),
    "pace" : MessageLookupByLibrary.simpleMessage("Pace"),
    "select_language" : MessageLookupByLibrary.simpleMessage("Select Language"),
    "prediction_formula" : MessageLookupByLibrary.simpleMessage("Prediction Formula"),
    "metric_system" : MessageLookupByLibrary.simpleMessage("Metric System"),
    "predicted_races" : MessageLookupByLibrary.simpleMessage("Predicted Races"),
    "settings" : MessageLookupByLibrary.simpleMessage("Settings"),
    "about_us" : MessageLookupByLibrary.simpleMessage("About Us"),
    "sentance1" : MessageLookupByLibrary.simpleMessage("The working group of the Armor Athlete application consists of track and field athletes and coaches. The application collects useful tools for use by track and field athletes and coaches. Tools supported in the first version include:"),
    "sentance2" : MessageLookupByLibrary.simpleMessage("Prediction of race time"),
    "sentance3" : MessageLookupByLibrary.simpleMessage("Calculation of body mass index"),
    "sentance4" : MessageLookupByLibrary.simpleMessage("You can suggest new tools by sending us an email."),
    "your_name" : MessageLookupByLibrary.simpleMessage("Your Name"),
    "your_email" : MessageLookupByLibrary.simpleMessage("Your Email"),
    "message" : MessageLookupByLibrary.simpleMessage("Message"),
    "submit" : MessageLookupByLibrary.simpleMessage("Submit"),
    "english" : MessageLookupByLibrary.simpleMessage("English"),
    "metric" : MessageLookupByLibrary.simpleMessage("Metric"),
    "mile" : MessageLookupByLibrary.simpleMessage("Mile"),
    "finnish" : MessageLookupByLibrary.simpleMessage("Finnish"),
    "height" : MessageLookupByLibrary.simpleMessage("Height"),
    "centimeters" : MessageLookupByLibrary.simpleMessage("centimeters"),
    "weight" : MessageLookupByLibrary.simpleMessage("Weight"),
    "kilograms" : MessageLookupByLibrary.simpleMessage("kilograms"),
    "compute" : MessageLookupByLibrary.simpleMessage("Compute"),
    "your" : MessageLookupByLibrary.simpleMessage("Your"),
    "categories" : MessageLookupByLibrary.simpleMessage("Categories"),
    "body_mass_index" : MessageLookupByLibrary.simpleMessage("Body Mass Index"),
    "under_weight" : MessageLookupByLibrary.simpleMessage("Underweight"),
    "normal_weight" : MessageLookupByLibrary.simpleMessage("Normal weight"),
    "over_weight" : MessageLookupByLibrary.simpleMessage("Overweight"),
    "obesity" : MessageLookupByLibrary.simpleMessage("Obesity"),
    "greater" : MessageLookupByLibrary.simpleMessage("greater"),
    "of_text" : MessageLookupByLibrary.simpleMessage("of"),
    "or" : MessageLookupByLibrary.simpleMessage("or"),
    "bmiText" : MessageLookupByLibrary.simpleMessage("BMI of 30 or greater"),
    "bmi_categories_text" : MessageLookupByLibrary.simpleMessage("BMI Categories"),
  };
}
