// DO NOT EDIT. This is code generated via package:intl/generate_localized.dart
// This is a library that provides messages for a ko locale. All the
// messages from the main program should be duplicated here with the same
// function name.

// Ignore issues from commonly used lints in this file.
// ignore_for_file:unnecessary_brace_in_string_interps, unnecessary_new
// ignore_for_file:prefer_single_quotes,comment_references, directives_ordering
// ignore_for_file:annotate_overrides,prefer_generic_function_type_aliases
// ignore_for_file:unused_import, file_names

import 'package:intl/intl.dart';
import 'package:intl/message_lookup_by_library.dart';

final messages = new MessageLookup();

typedef String MessageIfAbsent(String messageStr, List<dynamic> args);

class MessageLookup extends MessageLookupByLibrary {
  String get localeName => 'fi';

  static m0(id) => "Order: #${id} has been canceled";

  static m1(productName) => "${productName} fff";

  final messages = _notInlinedMessages(_notInlinedMessages);
  static _notInlinedMessages(_) => <String, Function> {
    "language" : MessageLookupByLibrary.simpleMessage("kieli"),
    "race_time_predictor" : MessageLookupByLibrary.simpleMessage("Kilpailuajan ennustaja"),
    "previous_race_information" : MessageLookupByLibrary.simpleMessage("Aiemmat kilpailutiedot"),
    "distance" : MessageLookupByLibrary.simpleMessage("Matka"),
    "time" : MessageLookupByLibrary.simpleMessage("Aika"),
    "done" : MessageLookupByLibrary.simpleMessage("Tehty"),
    "predict" : MessageLookupByLibrary.simpleMessage("Ennusta"),
    "finish_time" : MessageLookupByLibrary.simpleMessage("Loppuaika"),
    "pace" : MessageLookupByLibrary.simpleMessage("Vauhti"),
    "select_language" : MessageLookupByLibrary.simpleMessage("Valitse kieli"),
    "prediction_formula" : MessageLookupByLibrary.simpleMessage("Ennustettavat matkat"),
    "metric_system" : MessageLookupByLibrary.simpleMessage("Metrijärjestelmä"),
    "predicted_races" : MessageLookupByLibrary.simpleMessage("Ennustetut kilpailut"),
    "settings" : MessageLookupByLibrary.simpleMessage("Asetukset"),
    "english" : MessageLookupByLibrary.simpleMessage("Englanti"),
    "metric" : MessageLookupByLibrary.simpleMessage("Metrinen"),
    "mile" : MessageLookupByLibrary.simpleMessage("Maili"),
    "finnish" : MessageLookupByLibrary.simpleMessage("Suomi"),
    "about_us" : MessageLookupByLibrary.simpleMessage("Meistä"),
    "sentance1" : MessageLookupByLibrary.simpleMessage("Armour Athlete sovelluksen työryhmässä on yleisurheiljoita ja valmentajia. Sovellukseen kerätään hyödyllisiä työkaluja yleisurheilijoiden ja valmentajien käyttöön. Ensimmäisessä versiossa tuettuja työkaluja ovat:"),
    "sentance2" : MessageLookupByLibrary.simpleMessage("Kilpailuajan ennustaminen"),
    "sentance3" : MessageLookupByLibrary.simpleMessage("Painoindeksin laskeminen"),
    "sentance4" : MessageLookupByLibrary.simpleMessage("Voit ehdottaa uusia työkaluja lähettämällä meille sähköpostia."),
    "your_name" : MessageLookupByLibrary.simpleMessage("Sinun nimesi"),
    "your_email" : MessageLookupByLibrary.simpleMessage("Sähköpostisi"),
    "message" : MessageLookupByLibrary.simpleMessage("Viesti"),
    "submit" : MessageLookupByLibrary.simpleMessage("Lähetä"),
    "height" : MessageLookupByLibrary.simpleMessage("Pituus"),
    "centimeters" : MessageLookupByLibrary.simpleMessage("senttimetriä"),
    "weight" : MessageLookupByLibrary.simpleMessage("Paino"),
    "kilograms" : MessageLookupByLibrary.simpleMessage("kiloa"),
    "compute" : MessageLookupByLibrary.simpleMessage("Laskea"),
    "your" : MessageLookupByLibrary.simpleMessage("Sinun"),
    "body_mass_index" : MessageLookupByLibrary.simpleMessage("Painoindeksi"),
    "under_weight" : MessageLookupByLibrary.simpleMessage("Alipainoinen"),
    "normal_weight" : MessageLookupByLibrary.simpleMessage("Normaali paino"),
    "over_weight" : MessageLookupByLibrary.simpleMessage("Ylipainoinen"),
    "obesity" : MessageLookupByLibrary.simpleMessage("Lihavuus"),
    "greater" : MessageLookupByLibrary.simpleMessage("suurempi"),
    "of_text" : MessageLookupByLibrary.simpleMessage("/"),
    "or" : MessageLookupByLibrary.simpleMessage("tai"),
    "bmiText" : MessageLookupByLibrary.simpleMessage("30"),
    "bmi_categories_text" : MessageLookupByLibrary.simpleMessage("BMI raja-arvot aikuisille"),
  };
}
