import 'package:flutter/material.dart';

class CustomToggleButton extends StatefulWidget {
  final String activeImage;
  final String inactiveImage;

  CustomToggleButton({required this.activeImage, required this.inactiveImage});

  @override
  _CustomToggleButtonState createState() => _CustomToggleButtonState();
}

class _CustomToggleButtonState extends State<CustomToggleButton> {
  bool _isActive = false;

  void toggleButton() {
    setState(() {
      _isActive = !_isActive;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: toggleButton,
      child: Column(
        children: <Widget>[
          Image.asset(
            _isActive ? widget.activeImage : widget.inactiveImage,
            width: 50,
            height: 30, fit: BoxFit.fitHeight,
          ),
        ],
      ),
    );
  }
}