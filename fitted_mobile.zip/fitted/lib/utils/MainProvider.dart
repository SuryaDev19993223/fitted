import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart';

class MainProvider with ChangeNotifier {
  int formulaAlgorithm = 0;
  int metricMethod = 0;
  List distanceList = [

    {
      "distance": 100,
      "displayDistance": "100 m",
      "finishTime": "12.0",
      "pace": "3:13",
      "status" : true
    },
    {
      "distance": 200,
      "displayDistance": "200 m",
      "finishTime": "25.0",
      "pace": "3:21",
      "status" : true
    },
    {
      "distance": 400,
      "displayDistance": "400 m",
      "finishTime": "52.2",
      "pace": "3:30",
      "status" : true
    },
    {
      "distance": 500,
      "displayDistance": "500 m",
      "finishTime": "06.1",
      "pace": "3:33",
      "status" : true
    },
    {
      "distance": 800,
      "displayDistance": "800 m",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 1000,
      "displayDistance": "1000 m",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 1500,
      "displayDistance": "1500 m",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 1609.34,
      "displayDistance": "1 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

    {
      "distance": 2000,
      "displayDistance": "2 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 3000,
      "displayDistance": "3 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 3218.69,
      "displayDistance": "2 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

    {
      "distance": 4000,
      "displayDistance": "4 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 4828.03,
      "displayDistance": "3 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 5000,
      "displayDistance": "5 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 8000,
      "displayDistance": "8 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 8046.72,
      "displayDistance": "5 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 10000,
      "displayDistance": "10 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 12000,
      "displayDistance": "12 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 15000,
      "displayDistance": "15 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 16093.4,
      "displayDistance": "10 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

    {
      "distance": 21097.5,
      "displayDistance": "Half marathon",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 42195,
      "displayDistance": "Marathon",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

  ];
  List vo2DistanceList = [
    {
      "distance": 1500,
      "displayDistance": "1500 m",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 1609.34,
      "displayDistance": "1 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

    {
      "distance": 2000,
      "displayDistance": "2 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 3000,
      "displayDistance": "3 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 3218.69,
      "displayDistance": "2 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

    {
      "distance": 4000,
      "displayDistance": "4 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 4828.03,
      "displayDistance": "3 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 5000,
      "displayDistance": "5 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 8000,
      "displayDistance": "8 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 8046.72,
      "displayDistance": "5 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 10000,
      "displayDistance": "10 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 12000,
      "displayDistance": "12 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 15000,
      "displayDistance": "15 km",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 16093.4,
      "displayDistance": "10 mile",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

    {
      "distance": 21097.5,
      "displayDistance": "Half marathon",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },
    {
      "distance": 42195,
      "displayDistance": "Marathon",
      "finishTime": "48.8",
      "pace": "3:39",
      "status" : true
    },

  ];
  var currentDistanceList;

  int get count => formulaAlgorithm;

  void changeAlgorithm() {
    if(this.formulaAlgorithm == 0) {
      currentDistanceList = vo2DistanceList;
    } else {
      currentDistanceList = distanceList;
    }
  }

  void changeDistanceStatus(index, value) {
    distanceList[index]['status'] = value;
  }

}