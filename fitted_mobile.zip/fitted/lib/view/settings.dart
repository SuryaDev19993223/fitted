import 'dart:convert';

import 'package:fitted/controllers/auth_controller.dart';
import 'package:fitted/utils/Configs.dart';
import 'package:fitted/utils/custome_toggle.dart';
import 'package:fitted/view/auth/login.dart';
import 'package:fitted/view/auth/update_email_screen.dart';
import 'package:fitted/view/auth/update_password_screen.dart';
import 'package:fitted/view/auth/update_username_screen.dart';
import 'package:fitted/widgets/custom_inkwell_btn.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SettingsView extends StatefulWidget {
  SettingsView(
      {Key? key})
      : super(key: key);

  @override
  State<SettingsView > createState() => _MeasureViewState();
}

class _MeasureViewState extends State<SettingsView>  {
  bool loading = false;
  String name = '';
  String email = '';
  String passwordChangedTime = '';
  AuthController authController  = new AuthController();

  void initState() {
    super.initState();
    loadUserInformation();
  }

  Future<void> loadUserInformation() async {
    setState(() {
      loading = true;
    });
    final sharedPreferences = await SharedPreferences.getInstance();
    if(sharedPreferences.containsKey('user')){
      var user =  json.decode(sharedPreferences.getString('user')!);
      String dateString = user['updated_at'];
      DateTime date1 = DateTime.parse(dateString);
      final date2 = DateTime.now();
      final difference = date2.difference(date1).inDays;
      setState(()  {
        name = user['name'];
        email = user['email'];
        passwordChangedTime = difference.toString();
        loading = false;
      });
    }
  }

  Future<void> logOutPost() async {
    setState(() {
      loading = true;
    });
    final sharedPreferences = await SharedPreferences.getInstance();
    var user = json.decode(sharedPreferences.getString('user')!);
    var userID = user['id'].toString();
    var responseBack = await authController.signOutRepo(userID);
    var responseJson = json.decode(responseBack);
    if(responseJson['code'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          backgroundColor: Colors.green,
            content:
            Text('Success', style: TextStyle(color: Colors.white),),
            duration: Duration(seconds: 2)),
      );
      sharedPreferences.remove('user');
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginView()));
    }
    setState(() {
      loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(padding: EdgeInsets.only( left:  Config(context).appHeight(5),  right:  Config(context).appHeight(5)),
            child: ListView(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            logOutPost();

                          },
                          child: Image.asset('assets/images/back_icon.png'),
                        ),
                        Text("Settings ", style: TextStyle(color: Color(0xff3C3A36) , fontSize: 24, fontWeight: FontWeight.w600),),
                        SizedBox(width: 10,)
                      ],
                    ),
                    SizedBox(height: 30,),
                    Image.asset('assets/images/setting.png'),
                    SizedBox(height: 30,),
                    Container(
                      width: Config(context).appWidth(90),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Row(
                            children: [
                              Image.asset('assets/images/setting_notification.png'),
                              SizedBox(width: 15,),
                              Text("Notification", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 20, fontWeight: FontWeight.w500),),
                            ],
                          ),
                          CustomToggleButton(
                            activeImage: 'assets/images/toggle_active.png',
                            inactiveImage: 'assets/images/toggle_inactive.png',
                          ),
                        ],
                      )
                    ),
                    SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.start,
                      children: [
                        Text("Account information", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 20, fontWeight: FontWeight.w600),),
                      ],
                    ),
                    SizedBox(height: 10,),
                    CustomInkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>UpdateUserNameScreen()));
                      },
                      child:
                    Container(
                        width: Config(context).appWidth(90),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                            borderRadius: BorderRadius.circular(10)
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Image.asset('assets/images/setting_notification.png'),
                                SizedBox(width: 15,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Name", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 20, fontWeight: FontWeight.w600),),
                                    Text(name, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                                  ],
                                )
                              ],
                            ),
                            Image.asset('assets/images/next_icon.png')
                          ],
                        )
                    )),
                    SizedBox(height: 20,),
                    CustomInkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>UpdateEmailScreen()));
                      },
                      child:
                    Container(
                        width: Config(context).appWidth(90),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                            borderRadius: BorderRadius.circular(10)
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                        child: Row(
                          mainAxisAlignment: MainAxisAlignment.spaceBetween,
                          children: [
                            Row(
                              children: [
                                Image.asset('assets/images/setting_email.png'),
                                SizedBox(width: 15,),
                                Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text("Email", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 20, fontWeight: FontWeight.w600),),
                                    Text(email, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                                  ],
                                )
                              ],
                            ),
                            Image.asset('assets/images/next_icon.png')
                          ],
                        )
                    )),
                    SizedBox(height: 20,),
                   CustomInkWell(
                     onTap: (){
                       Navigator.push(context, MaterialPageRoute(builder: (context)=>UpdatePasswordScreen()));
                     },
                     child:  Container(
                         width: Config(context).appWidth(90),
                         decoration: BoxDecoration(
                             border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                             borderRadius: BorderRadius.circular(10)
                         ),
                         padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                         child: Row(
                           mainAxisAlignment: MainAxisAlignment.spaceBetween,
                           children: [
                             Row(
                               children: [
                                 Image.asset('assets/images/setting_password.png'),
                                 SizedBox(width: 15,),
                                 Column(
                                   crossAxisAlignment: CrossAxisAlignment.start,
                                   children: [
                                     Text("Password", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 20, fontWeight: FontWeight.w600),),
                                     Text(  "changed " + passwordChangedTime +  "days ago",
                                       textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                                   ],
                                 )
                               ],
                             ),
                             Image.asset('assets/images/next_icon.png')
                           ],
                         )
                     ),
                   )
                  ],
                ),



              ],
            ),
          ),

          loading? Align(
            alignment: Alignment.center,
            child: Image.asset(
              "assets/images/loading.gif",
              height: 60.0,
              width: 60.0,
            ),
          ) : Container(),
        ],
      ),
    );
  }




}


//

