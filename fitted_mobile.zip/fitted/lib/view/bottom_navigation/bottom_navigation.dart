import 'package:fitted/view/measure.dart';
import 'package:fitted/view/measurement.dart';
import 'package:fitted/view/settings.dart';
import 'package:flutter/material.dart';


class BottomNavigation extends StatefulWidget {
  dynamic currentTab;
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  BottomNavigation({
    required Key key,
    this.currentTab,
  })  : super(key: key);


  @override
  _MyBottomNavigationBarState createState() => _MyBottomNavigationBarState();
}

class _MyBottomNavigationBarState extends State<BottomNavigation> {
  int _currentIndex = 0;
  final List<Widget> _screens = [
    Measure(),
    Measurement(),
    SettingsView(),
  ];

  Color _selecteditemcolor = Color(0xff5BA092);
  Color _unselecteditemcolor = Color(0xff3C3A36);

  initState() {
    super.initState();
    _currentIndex = widget.currentTab;
  }


  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: _screens[_currentIndex],
      bottomNavigationBar: Container(

        height: 90,
        decoration: BoxDecoration(
          // border: Border(top: BorderSide(color: Color(0xff3C3A36), width: 1.0))
            borderRadius:  BorderRadius.only(
              topLeft: Radius.circular(20.0),
              topRight: Radius.circular(20.0),
            ),
            border: Border.all(color: Color(0xff3C3A36), width: 1.0)
        ),
        child: ClipRRect(
            borderRadius: BorderRadius.only(
              topLeft: Radius.circular(40.0),
              topRight: Radius.circular(40.0),
            ),
            child: Container(
              child: BottomNavigationBar(
                selectedItemColor: _selecteditemcolor,
                unselectedItemColor: _unselecteditemcolor,
                showSelectedLabels: true,
                selectedLabelStyle: TextStyle(fontSize: 14),
                unselectedFontSize: 14,
                backgroundColor: Colors.white,
                currentIndex: _currentIndex,
                onTap: (index) {
                  setState(() {
                    _currentIndex = index;
                  });
                },
                items: [
                  BottomNavigationBarItem(
                    icon: Image.asset("assets/images/measure_icon.png",
                        width: 45,
                        height: 45,
                        color: _currentIndex == 0
                            ? _selecteditemcolor
                            : _unselecteditemcolor),
                    label: 'Measure',
                  ),
                  BottomNavigationBarItem(
                    icon: Image.asset("assets/images/measurement_icon.png",
                        width: 40,
                        height: 40,
                        color: _currentIndex == 1
                            ? _selecteditemcolor
                            : _unselecteditemcolor),
                    label: 'Measurements',
                  ),
                  BottomNavigationBarItem(
                    icon: Image.asset("assets/images/setting_icon.png",
                        width: 40,
                        height: 40,
                        color: _currentIndex == 2
                            ? _selecteditemcolor
                            : _unselecteditemcolor),
                    label: 'Settings',
                  ),
                ],
              ),
            )
        ),
      ),
    );

  }
}
