import 'package:fitted/utils/Configs.dart';
import 'package:fitted/view/auth/login.dart';
import 'package:fitted/view/bottom_navigation/bottom_navigation.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SplashView extends StatefulWidget {
  SplashView(
      {Key? key})
      : super(key: key);
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();

  @override
  State<SplashView > createState() => _SplashViewState();
}
class _SplashViewState extends State<SplashView>  {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(padding: EdgeInsets.only(top: Config(context).appHeight(15), left:  Config(context).appHeight(7),  right:  Config(context).appHeight(7)),
            child:SingleChildScrollView(child: Column(
              children: [
                Image.asset('assets/images/fitted_logo.png'),
                SizedBox(height: 30,),
                Image.asset('assets/images/splash_image.png'),
                SizedBox(height: 30,),
                GestureDetector(
                  onTap: () {
                    loginCheck();
                  },
                  child: Container(
                    width: Config(context).appWidth(85),
                    height: 50,
                    decoration:  BoxDecoration(
                        color: Color(0xffFFFF00),
                        borderRadius: BorderRadius.circular(10)
                    ),
                    alignment: Alignment.center,
                    child: Center(
                      child: Text("Let's Start", style: TextStyle(color: Color(0xff3C3A36) , fontSize: 16, fontWeight: FontWeight.w500),),
                    ),
                  ),
                )
              ],
            )),
          )
          
        ],
      ),
    );
  }

  Future<void> loginCheck() async {
    final sharedPreferences = await SharedPreferences.getInstance();
    if(sharedPreferences.containsKey('user')){
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomNavigation( currentTab: 0, key: widget.scaffoldKey,)));
    } else {
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginView()));
    }
  }

}

