import 'dart:convert';
import 'dart:io';
import 'package:fitted/controllers/api_controller.dart';
import 'package:fitted/utils/Configs.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:camera/camera.dart';
import 'bottom_navigation/bottom_navigation.dart';

class MeasureDetail extends StatefulWidget {
  MeasureDetail(
      {Key? key})
      : super(key: key);
  GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  @override
  State<MeasureDetail> createState() => _MeasureDetailViewState();
}

class _MeasureDetailViewState extends State<MeasureDetail>  {

  TextEditingController heightTextController = new TextEditingController();
  TextEditingController weightTextController = new TextEditingController();
  APIController apiController = new APIController();
  bool isSwitched = false;
  bool genderSwitched = false;
  bool loading = false;
  int index = 0;
  var currentImage = "assets/images/image_empty.png";
  String photoName = "Photo Front";
  String username = "";
  bool initialPageActive = true;
  int  isFrontUploaded = 0;
  int isSideUploaded = 0;
  bool isLoaded = false;
  bool isCameraSelected = false;
  var frontPhotoResponse ;
  var rightPhotoResponse ;
  var profileResponse ;
  var sizeResponse ;
  File? _image;
  final picker = ImagePicker();
  String progressText = "Creating profile";
  List<CameraDescription>? cameras; //list out the camera available
  CameraController? controller;

  void initState() {
    loadCamera();
    super.initState();
    loadUserInformation();
  }

  loadCamera() async {
    cameras = await availableCameras();
    if(cameras != null){
      controller = CameraController(cameras![0], ResolutionPreset.max);
      //cameras[0] = first camera, change to 1 to another camera

      controller!.initialize().then((_) {
        if (!mounted) {
          return;
        }
        setState(() {});
      });
    }else{
      print("NO any camera found");
    }
  }

  Future<void> loadUserInformation () async {
    final sharedPreferences = await SharedPreferences.getInstance();
    if(sharedPreferences.containsKey('user')){
      var user =  json.decode(sharedPreferences.getString('user')!);
      setState(()  {
        username = user['name'];
      });
    }
  }

  Future getImageFromGallery() async {
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    setState(() {
      if (pickedFile != null) {
        _image = File(pickedFile.path);
        currentImage = _image!.path;
        isLoaded = true;
        if(isFrontUploaded == 1) {
          postFrontPhotoHandle();
        }
        if(isSideUploaded == 1) {
          postSidePhotoHandle();
        }
      }
    });
  }

//Image Picker function to get image from camera
  Future getImageFromCamera() async {
    // final pickedFile = await picker.pickImage(source: ImageSource.camera);
    //
    // setState(() {
    //   if (pickedFile != null) {
    //     _image = File(pickedFile.path);
    //     currentImage = _image!.path;
    //     isLoaded = true;
    //     if(isFrontUploaded == 1) {
    //       postFrontPhotoHandle();
    //     }
    //     if(isSideUploaded == 1) {
    //       postSidePhotoHandle();
    //     }
    //   }
    // });
    setState(() {
      isCameraSelected = true;
    });
  }

  Future showOptions() async {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoActionSheet(
        actions: [
          CupertinoActionSheetAction(
            child: Text('Photo Gallery'),
            onPressed: () {
              // close the options modal
              Navigator.of(context).pop();
              // get image from gallery
              getImageFromGallery();
            },
          ),
          CupertinoActionSheetAction(
            child: Text('Camera'),
            onPressed: () {
              // close the options modal
              Navigator.of(context).pop();
              // get image from camera
              getImageFromCamera();
            },
          ),
        ],
      ),
    );
  }

  Future<void> postFrontPhotoHandle() async {
    setState(() {
      loading = true;
      progressText = "Processing Front Photo";
    });
    final bytes = File(_image!.path).readAsBytesSync();
    String img64 = base64Encode(bytes);
    var responseBack = await apiController.cloudPhotoPost(1,img64);
    print(responseBack);
    frontPhotoResponse = json.decode(responseBack);
    if (frontPhotoResponse['code'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            backgroundColor: Colors.green,
            content:
            Text('Front Photo Posted.', style: TextStyle(color: Colors.white),),
            duration: Duration(seconds: 2)
        ),
      );
      setState(() {
        isLoaded = false;
        loading = false;
        isFrontUploaded =2;
        initialPageActive = true;
        isCameraSelected = false;
      });
    }
  }

  Future<void> postSidePhotoHandle() async {
    setState(() {
      loading = true;
      progressText = "Processing Side Photo";
    });
    final bytes = File(_image!.path).readAsBytesSync();
    String img64 = base64Encode(bytes);
    var responseBack = await apiController.cloudPhotoPost(2,img64);
    print(responseBack);
    rightPhotoResponse= json.decode(responseBack);
    if (rightPhotoResponse['code'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            backgroundColor: Colors.green,
            content:
            Text('Side Photo Posted.', style: TextStyle(color: Colors.white),),
            duration: Duration(seconds: 2)),
      );

    }
    setState(() {
      isLoaded = false;
      isSideUploaded =2;
      initialPageActive = true;
      isCameraSelected = false;
    });
    postProfileCreation();
  }

  Future<void> postProfileCreation() async {
    setState(() {
      loading = true;
      progressText = "Creating Profile";
    });
    var frontTicket = frontPhotoResponse['data']['ticket'];
    var sideTicket = rightPhotoResponse['data']['ticket'];
    var responseBack = await apiController.cloudProfilePost(frontTicket, sideTicket);
    profileResponse= json.decode(responseBack);
    if (profileResponse['code'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            backgroundColor: Colors.green,
            content:
            Text('Profile Created.', style: TextStyle(color: Colors.white),),
            duration: Duration(seconds: 2)),
      );

    }
    setState(() {
      loading = false;
      isLoaded = false;
    });
    postSizeCalculation();
  }

  Future<void> postSizeCalculation() async {
    setState(() {
      loading = true;
      progressText = "Calculating Size";
    });

    var measureId = profileResponse['data']['measureId'];
    var frontProfileBody = profileResponse['data']['frontProfileBody'];
    var sideProfileBody = profileResponse['data']['sideProfileBody'];
    var responseBack = await apiController.cloudSizePost(measureId, frontProfileBody, sideProfileBody);
    sizeResponse= json.decode(responseBack);
    print(sizeResponse);
    if (sizeResponse['code'] == 200) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
            backgroundColor: Colors.green,
            content:
            Text('Size Calculated.', style: TextStyle(color: Colors.white),),
            duration: Duration(seconds: 2)),
      );
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomNavigation(currentTab: 1, key: widget.scaffoldKey,)));
    }
    setState(() {
      loading = false;
      isLoaded = false;
    });
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          !isCameraSelected ? Padding(padding: EdgeInsets.only( left:  Config(context).appHeight(5),  right:  Config(context).appHeight(5)) ,
            child: ListView(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Image.asset('assets/images/back_icon.png'),
                        ),
                        initialPageActive? Text(username, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 20, fontWeight: FontWeight.w600),)
                        : Text(isFrontUploaded == 1 ? "Photo Front" : "Photo Side", style: TextStyle(color: Color(0xff3C3A36) , fontSize: 24, fontWeight: FontWeight.w600),),
                        SizedBox(width: 10,)
                      ],
                    ),
                    SizedBox(height: 30,),
                    initialPageActive? Container(
                      width: Config(context).appWidth(90),
                      child: Column(
                        children: [
                          Text("You’re almost there! Just two images and you’ll be all set. One front, one side. Get those pearly whites ready!",
                            textAlign: TextAlign.center, style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w400),),
                          SizedBox(height: 30,),
                          GestureDetector(
                            onTap: () {
                              goToFrontProfile();
                            },
                            child: Container(
                              width: Config(context).appWidth(85),
                              height: 50,
                              decoration: isFrontUploaded == 2 ? BoxDecoration(
                                  color: Color(0xffFFFF00),
                                  borderRadius: BorderRadius.circular(10)
                              ): BoxDecoration(
                                  border: Border.all(color: Color(0xffBEBAB3), width: 1), borderRadius: BorderRadius.circular(10)
                              ),
                              alignment: Alignment.center,
                              child: Center(
                                child: Text("Front Profile", style: TextStyle(color: Color(0xff3C3A36) ,  fontSize: 14, fontWeight: FontWeight.w600),),
                              ),
                            ),
                          ),
                          SizedBox(height: 10,),
                          GestureDetector(
                            onTap: () {
                              goToSideProfile();
                            },
                            child: Container(
                              width: Config(context).appWidth(85),
                              height: 50,
                              decoration: isSideUploaded == 2?  BoxDecoration(
                                  color: Color(0xffFFFF00),
                                  borderRadius: BorderRadius.circular(10)
                              ) :
                              BoxDecoration(
                                border: Border.all(color: Color(0xffBEBAB3), width: 1), borderRadius: BorderRadius.circular(10)
                              ),
                              alignment: Alignment.center,
                              child: Center(
                                child: Text("Side Profile", style: TextStyle(color: Color(0xff3C3A36) ,  fontSize: 14, fontWeight: FontWeight.w600),),
                              ),
                            ),
                          ),
                        ],
                      )
                    )
                        : Container(
                      width: Config(context).appWidth(80),
                      height: Config(context).appHeight(66),
                      child: Center(
                        child: !isLoaded ? Image.asset(isFrontUploaded == 1 ? "assets/images/front_silhouette.png" :  "assets/images/side_silhouette.png" , height: Config(context).appHeight(60), )
                        : Image.file(_image!),
                      ),
                    ),

                    SizedBox(height: 30,),
                    !initialPageActive ? Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // GestureDetector(
                        //   onTap: () {
                        //     showInstructionModal();
                        //   },
                        //   child: Container(
                        //     width: 50,
                        //     height: 50,
                        //     decoration: BoxDecoration(
                        //         borderRadius: BorderRadius.circular(25), color: Color(0xff5BA092)
                        //     ),
                        //     child: Center(
                        //       child: Icon(CupertinoIcons.hand_draw_fill, color: Colors.white,),
                        //     ),
                        //   ),
                        // ),

                      ],
                    ) : Container()

                  ],
                ),

              ],
            ),
          )
          : Container(),
          isFrontUploaded == 1 ? Container(
            color: Colors.white,
            height: Config(context).appHeight(100),
            width: Config(context).appWidth(100),
            child: Column(
              children: [
                SizedBox(height: Config(context).appHeight(10),),
                isFrontUploaded == 1 ?Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("Results will be best if you wear clothes that more form fitting.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black , decoration: TextDecoration.none, fontSize: 14, fontWeight: FontWeight.w400),),
                ) : Container(),
                SizedBox(height: Config(context).appHeight(10),),
                Image.asset('assets/images/front_instruction.png'),
                SizedBox(height: Config(context).appHeight(10),),
                GestureDetector(
                  onTap: () {
                    if(!loading){
                      getImageFromCamera();
                    }
                  },
                  child: Container(
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7), color: Color(0xff5BA092)
                    ),
                    child: Center(
                      child: Text("Next", style: TextStyle(color: Colors.white ,  fontSize: 16, fontWeight: FontWeight.w600),),
                    ),
                  ),
                )
              ],
            ),
          ) : Container(),
          isSideUploaded == 1 ? Container(
            color: Colors.white,
            height: Config(context).appHeight(100),
            width: Config(context).appWidth(100),
            child: Column(
              children: [
                SizedBox(height:  Config(context).appHeight(20),),
                Image.asset('assets/images/side_instruction.png'),
                SizedBox(height: Config(context).appHeight(10),),
                GestureDetector(
                  onTap: () {
                    if(!loading){
                      getImageFromCamera();
                    }
                  },
                  child: Container(
                    width: 100,
                    height: 50,
                    decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(7), color: Color(0xff5BA092)
                    ),
                    child: Center(
                      child: Text("Next", style: TextStyle(color: Colors.white ,  fontSize: 16, fontWeight: FontWeight.w600),),
                    ),
                  ),
                )
              ],
            ),
          ) : Container(),
          isCameraSelected ? cameraPreviewScreen(context): Container(),
          loading? Align(
              alignment: Alignment.center,
              child: SizedBox(
                height: Config(context).appHeight(20),
                child:  Column(
                  children: [
                    Image.asset(
                      "assets/images/loading.gif",
                      height: 60.0,
                      width: 60.0,
                    ),
                    Text(progressText + "...", style: TextStyle(fontSize: 14, color: Colors.black87, fontWeight: FontWeight.w500),)
                  ],
                ),
              )
          ) : Container(),
        ],
      ),
    );
  }

  void goToFrontProfile() {
    setState(() {
      initialPageActive = false;
      isFrontUploaded = 1;
    });
  }

  void goToSideProfile() {
    setState(() {
      initialPageActive = false;
      isSideUploaded = 1;
    });
  }

  void changeImage() {

    setState(() {
      if(index == 0 ){
        currentImage = "assets/images/photo_front.png";
        index = 1;
      } else {
        currentImage = "assets/images/photo_right.png";
        index = 0;
      }

    });
  }


  Future showInstructionModal() async {
    showCupertinoModalPopup(
      context: context,
      builder: (context) => CupertinoActionSheet(
        actions: [
          Container(
            color: Colors.white,
            height: Config(context).appHeight(80),
            width: Config(context).appWidth(80),
            child: Column(
              children: [
                SizedBox(height: 20,),
                isFrontUploaded == 1 ?Padding(
                  padding: EdgeInsets.symmetric(horizontal: 5),
                  child: Text("Results will be best if you wear clothes that more form fitting.",
                    textAlign: TextAlign.center,
                    style: TextStyle(color: Colors.black , decoration: TextDecoration.none, fontSize: 14, fontWeight: FontWeight.w400),),
                ) : Container(),
                SizedBox(height: 30,),
                isFrontUploaded == 1 ? Image.asset('assets/images/front_instruction.png') : Container(),
                isSideUploaded == 1 ? Image.asset('assets/images/side_instruction.png') : Container(),
              ],
            ),
          )
        ],
      ),
    );
  }

  Widget cameraPreviewScreen(BuildContext context) {
    return Stack(
      children: [
        CameraPreview(controller!),
        Container( //show captured image
          width: Config(context).appWidth(100),
          height: Config(context).appHeight(100),
          child: Image.asset(isFrontUploaded == 1 ? 'assets/images/silhouette_front_overlay.png' : 'assets/images/silhouette_side_overlay.png'),
          //display captured image
        ),
        Align(
          alignment: Alignment.bottomCenter,
          child: Container(
              height: 100,
              width: Config(context).appWidth(100),
              padding: EdgeInsets.symmetric(horizontal: 10),
              decoration: BoxDecoration(
                  borderRadius: BorderRadius.only(topLeft: Radius.circular(15), topRight: Radius.circular(15)), color: Color(0xff5BA092)
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  InkWell(
                      onTap: ()  {
                        getImageFromGallery();
                      },
                      child: Icon(Icons.photo_library_outlined, color: Colors.white, size: 60,)
                  ),
                  InkWell(
                      onTap: () async {
                        try {
                          if(controller != null){ //check if contrller is not null
                            if(controller!.value.isInitialized){ //check if controller is initialized
                              // pickedFile = await controller!.takePicture(); //capture image
                              // final pickedFile = await picker.pickImage(source: ImageSource.camera);
                              XFile? image  = await controller!.takePicture();
                              _image = File(image.path);
                              setState(() {
                                currentImage = _image!.path;
                                isLoaded = true;
                                if(isFrontUploaded == 1) {
                                  postFrontPhotoHandle();
                                }
                                if(isSideUploaded == 1) {
                                  postSidePhotoHandle();
                                }

                              });
                            }
                          }
                        } catch (e) {
                          print(e); //show error
                        }
                      },
                      child: Icon(CupertinoIcons.camera_viewfinder, color: Colors.white, size: 60,)
                  ),
                  SizedBox(width: 60,)
                ],
              )
          ),
        )
      ],
    );
  }

}




