import 'dart:math';

import 'package:fitted/controllers/auth_provider.dart';
import 'package:fitted/widgets/colors.dart';
import 'package:fitted/widgets/custom_button.dart';
import 'package:fitted/widgets/custom_inkwell_btn.dart';
import 'package:fitted/widgets/custom_parent_widget.dart';
import 'package:fitted/widgets/custom_text.dart';
import 'package:fitted/widgets/custom_textfield.dart';
import 'package:fitted/widgets/validator.dart';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';


class UpdatePasswordScreen extends StatefulWidget {
  const UpdatePasswordScreen({super.key});

  @override
  State<UpdatePasswordScreen> createState() => _UpdatePasswordScreenState();
}

class _UpdatePasswordScreenState extends State<UpdatePasswordScreen> {
  final oldPassController = TextEditingController();
  final newPassController = TextEditingController();
  final confirmPassController = TextEditingController();
  final formKey = GlobalKey<FormState>();
  String errorText = "";
  // changePassword(BuildContext context, AuthProvider authProvider) async {
  //   if (formKey.currentState!.validate()) {
  //     errorText = "";
  //     authProvider.changePassword(oldPassController.text.toString().trim(),
  //         confirmPassController.text.toString().trim(),
  //         (bool isLogin, String message) async {
  //       if (isLogin) {
  //         //   Helper.toRemoveUntiScreen(context, SignInPage());
  //         Navigator.pop(context);
  //       } else {
  //         errorText = message;
  //         Helper.showSnack(context, message);
  //       }
  //     }, context);
  //   }
  // }

  @override
  Widget build(BuildContext context) {
    return CustomParentWidget(
      child: Consumer<AuthProvider>(builder: (context, authProvider, child) {
        return Scaffold(
            appBar: AppBar(
              elevation: 0,
              automaticallyImplyLeading: false,
              centerTitle: true,
              leading: CustomInkWell(
                onTap: () {
                  Navigator.pop(context);
                },
                child: Padding(
                  padding:  EdgeInsets.all(8.0),
                  child:  Icon(
                    Icons.arrow_back,
                    color: blackColor,
                  ),
                ),
              ),
            ),
            body: SingleChildScrollView(
              child: Form(
                key: formKey,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    //Space
                    const SizedBox(
                      height: 30,
                    ),
                    //
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      alignment: Alignment.center,
                      child: CustomText(
                        title: "Update password",
                        fontSize: 20,
                        color: blackColor,
                        fontWeight: FontWeight.w700,
                      ),
                    ),

                    // Container(
                    //   padding: const EdgeInsets.symmetric(horizontal: 18),
                    //   alignment: Alignment.centerLeft,
                    //   child: CustomText2(
                    //     title: "Update password",
                    //     fontSize: 20,
                    //
                    //     color: blackColor,
                    //     fontWeight: FontWeight.w700,
                    //   ),
                    // ),
                    //Space
                    const SizedBox(
                      height: 20,
                    ),
                    //Old Password
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Row(
                        children: [
                          Expanded(
                            child: CustomTextField(
                              obscureText: authProvider.isToggle,
                              controller: oldPassController,
                              keyboardType: TextInputType.visiblePassword,
                              textInputAction: TextInputAction.next,
                              onChanged: (_) {
                                setState(() {});
                                return null;
                              },
                              validation: oldPasswordField,
                              hintText:
                                  "Old Password",
                              hintFontSize: 13,
                              textFontSize: 15,
                              textHeight: 1.5,
                              contentPaddingLeft: 12,
                              isOutlineInputBorder: true,
                              isUnderlineInputBorder: false,
                              isOutlineInputBorderColor: blackColor,
                              isUnderlineInputBorderWidth: 0.8,
                              textFieldFillColor: whiteColor,
                              // suffixIconConstraints: BoxConstraints(
                              //   minWidth: 12,
                              // ),
                              suffixIcon: Container(
                                constraints: const BoxConstraints(
                                  maxWidth: 70,
                                  //maxWidth: 80
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomInkWell(
                                        onTap: () {
                                          setState(() {
                                            oldPassController.text = "";
                                          });
                                        },
                                        child: oldPassController.text.isEmpty
                                            ? const SizedBox()
                                            : Padding(
                                                padding:
                                                    const EdgeInsets.all(6.0),
                                                child: Image.asset(
                                                  "assets/icons/ic_clear.png",
                                                  scale: 4,
                                                ))),
                                    CustomInkWell(
                                      onTap: () {
                                        authProvider.toggleDone(index: 0);
                                      },
                                      child: authProvider.isToggle
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.all(6.0),
                                              child: Image.asset(
                                                "assets/images/ic_hide.png",
                                                scale: 4,
                                                color: greyColor,
                                              ))
                                          : Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Image.asset(
                                                "assets/images/ic_seen.png",
                                                scale: 4,
                                                color: greyColor,
                                              )),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    //Space
                    const SizedBox(
                      height: 10,
                    ),
                    //New Password
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Row(
                        children: [
                          Expanded(
                            child: CustomTextField(
                              obscureText: authProvider.isToggle1,
                              controller: newPassController,
                              keyboardType: TextInputType.visiblePassword,
                              textInputAction: TextInputAction.next,
                              onChanged: (_) {
                                setState(() {});
                                return null;
                              },
                              validation: validatePassword,
                              hintText:
                                  "New Password",
                              hintFontSize: 13,
                              textFontSize: 15,
                              textHeight: 1.5,
                              contentPaddingLeft: 12,
                              isOutlineInputBorder: true,
                              isUnderlineInputBorder: false,
                              isOutlineInputBorderColor: blackColor,
                              isUnderlineInputBorderWidth: 0.8,
                              textFieldFillColor: whiteColor,
                              // suffixIconConstraints: BoxConstraints(
                              //   minWidth: 12,
                              // ),
                              suffixIcon: Container(
                                constraints: const BoxConstraints(
                                  maxWidth: 70,
                                  //maxWidth: 80
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomInkWell(
                                        onTap: () {
                                          setState(() {
                                            newPassController.text = "";
                                          });
                                        },
                                        child: newPassController.text.isEmpty
                                            ? const SizedBox()
                                            : Padding(
                                                padding:
                                                    const EdgeInsets.all(6.0),
                                                child: Image.asset(
                                                  "assets/icons/ic_clear.png",
                                                  scale: 4,
                                                ))),
                                    CustomInkWell(
                                      onTap: () {
                                        authProvider.toggleDone(index: 1);
                                      },
                                      child: authProvider.isToggle1
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.all(6.0),
                                              child: Image.asset(
                                                "assets/images/ic_hide.png",
                                                scale: 4,
                                                color: greyColor,
                                              ))
                                          : Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Image.asset(
                                                "assets/images/ic_seen.png",
                                                scale: 4,
                                                color: greyColor,
                                              )),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    //Space
                    const SizedBox(
                      height: 10,
                    ),
                    //Confirm Password
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Row(
                        children: [
                          Expanded(
                            child: CustomTextField(
                              obscureText: authProvider.isToggle2,
                              controller: confirmPassController,
                              keyboardType: TextInputType.visiblePassword,
                              textInputAction: TextInputAction.done,
                              onChanged: (_) {
                                setState(() {});
                                return null;
                              },
                              validation: validateRepeatPassword,
                              hintText:
                                  "Confirm Password",
                              hintFontSize: 13,
                              textFontSize: 15,
                              textHeight: 1.5,
                              contentPaddingLeft: 12,
                              isOutlineInputBorder: true,
                              isUnderlineInputBorder: false,
                              isOutlineInputBorderColor: blackColor,
                              isUnderlineInputBorderWidth: 0.8,
                              textFieldFillColor: whiteColor,
                              // suffixIconConstraints: BoxConstraints(
                              //   minWidth: 12,
                              // ),
                              suffixIcon: Container(
                                constraints: const BoxConstraints(
                                  maxWidth: 70,
                                  //maxWidth: 80
                                ),
                                child: Row(
                                  mainAxisAlignment: MainAxisAlignment.end,
                                  children: [
                                    CustomInkWell(
                                        onTap: () {
                                          setState(() {
                                            confirmPassController.text = "";
                                          });
                                        },
                                        child: confirmPassController
                                                .text.isEmpty
                                            ? const SizedBox()
                                            : Padding(
                                                padding:
                                                    const EdgeInsets.all(6.0),
                                                child: Image.asset(
                                                  "assets/icons/ic_clear.png",
                                                  scale: 4,
                                                ))),
                                    CustomInkWell(
                                      onTap: () {
                                        authProvider.toggleDone(index: 2);
                                      },
                                      child: authProvider.isToggle2
                                          ? Padding(
                                              padding:
                                                  const EdgeInsets.all(6.0),
                                              child: Image.asset(
                                                "assets/images/ic_hide.png",
                                                scale: 4,
                                                color: greyColor,
                                              ))
                                          : Padding(
                                              padding:
                                                  const EdgeInsets.all(8.0),
                                              child: Image.asset(
                                                "assets/images/ic_seen.png",
                                                scale: 4,
                                                color: greyColor,
                                              )),
                                    ),
                                  ],
                                ),
                              ),
                            ),
                          )
                        ],
                      ),
                    ),
                    //Space
                    const SizedBox(
                      height: 30,
                    ),
                    //


                    // Container(
                    //   padding: const EdgeInsets.symmetric(horizontal: 18),
                    //   alignment: Alignment.centerLeft,
                    //   child: CustomText(
                    //     title: "${getTranslated("Your password must have at least", context)}:",
                    //     fontSize: 15,
                    //     color: blackColor,
                    //     fontWeight: FontWeight.w600,
                    //   ),
                    // ),
                    //Space
                    const SizedBox(
                      height: 8,
                    ),
                    //
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 18),
                      child: Stack(
                        children: [
                          CustomButton(
                            onPressed: () async {
                              // if (oldPassController.text.isEmpty ||
                              //     newPassController.text.isEmpty ||
                              //     confirmPassController.text.isEmpty) {
                              // } else {
                              //   if (authProvider.isLoading == true) {
                              //   } else {
                              //     changePassword(context, authProvider);
                              //   }
                              // }
                            },
                            btnHeight: 44,
                            btnRadius: 2,
                            title: 'Update Password',
                            fontWeight: FontWeight.w600,
                            btnColor: yellowColor,
                            textColor:blackColor,
                            fontSize: 14,
                          ),
                          if (authProvider.isLoading == true)
                            Positioned.directional(
                                textDirection: Directionality.of(context),
                                end: 20,
                                top: 0,
                                bottom: 0,
                                child: const Row(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  children: [
                                    SizedBox(
                                      height: 25,
                                      width: 25,
                                      child: CircularProgressIndicator(
                                        color: whiteColor,
                                        strokeWidth: 3,
                                      ),
                                    ),
                                  ],
                                ))
                        ],
                      ),
                    ),
                  ],
                ),
              ),
            ));
      }),
    );
  }
}
