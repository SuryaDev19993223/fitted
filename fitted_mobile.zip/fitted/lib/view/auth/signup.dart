import 'dart:convert';
import 'package:fitted/controllers/auth_controller.dart';
import 'package:fitted/view/auth/login.dart';
import 'package:fitted/view/bottom_navigation/bottom_navigation.dart';
import 'package:flutter/material.dart';
import 'package:fitted/utils/Configs.dart';
import 'package:shared_preferences/shared_preferences.dart';

class SignupView extends StatefulWidget {
  SignupView(
      {Key? key})
      : super(key: key);

  @override
  State<SignupView > createState() => _SignupViewState();
}

class _SignupViewState extends State<SignupView>  {
  @override
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController nameTextController = new TextEditingController();
  TextEditingController emailTextController = new TextEditingController();
  TextEditingController passwordTextController = new TextEditingController();
  TextEditingController confirmPasswordTextController = new TextEditingController();
  AuthController authController  = new AuthController();
  bool _obscureText = true;
  bool _obscureTextConfirm = true;

  int validateName(String name) {
    if(name.isEmpty) {
      return 1;
    } else {
      return 0;
    }
  }

  int validateEmail(String emailAddress) {
    String patttern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
    RegExp regExp = new RegExp(patttern);
    if (emailAddress.isEmpty || emailAddress.length == 0) {
      return 1;
    } else if (!regExp.hasMatch(emailAddress)) {
      return 2;
    } else {
      return 0;
    }
  }

  int validatePassword(String pswd) {
    if (pswd.isEmpty || pswd.length == 0) {
      return 1;
    } else if (pswd != null && pswd.isNotEmpty && pswd.length <= 5) {
      return 2;
    } else {
      return 0;
    }
  }

  int validateConfirmPassword(String pswd) {
    if (pswd.isEmpty || pswd.length == 0) {
      return 1;
    } else if (pswd != null && pswd.isNotEmpty && pswd.length <= 5) {
      return 2;
    }else if (pswd != passwordTextController.text) {
      return 3;
    } else {
      return 0;
    }
  }

  void _togglePassword() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }

  void _toggleConfirmPassword() {
    setState(() {
      _obscureTextConfirm = !_obscureTextConfirm;
    });
  }

  Future<void> signupPost() async {
    if(_formKey.currentState!.validate()) {
      var responseJson;
      var name = nameTextController.text;
      var email = emailTextController.text;
      var password = passwordTextController.text;
      var responseBack = await authController.signupRepo(name, email, password);
      responseJson = json.decode(responseBack);
      if(responseJson['code'] == 200) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content: Text('Success', style: TextStyle(color: Colors.white),),
              duration: Duration(seconds: 1),
          backgroundColor: Colors.green,
          ),
        );
        Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginView()));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content:
              Text('Issue has been occurred', style: TextStyle(color: Colors.white),),
              duration: Duration(seconds: 2)),
        );
      }
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(padding: EdgeInsets.only( left:  Config(context).appHeight(5),  right:  Config(context).appHeight(5)),
            child: ListView(
              children: [
                Image.asset('assets/images/add_icon.png', height: Config(context).appWidth(25), fit: BoxFit.fitHeight,),
                SizedBox(height: 30,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text("Sign up", style: TextStyle(color: Color(0xff3C3A36) , fontSize: 24, fontWeight: FontWeight.w600),),
                    SizedBox(height: 10,),
                    Text("Create your account", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                  ],
                ),
                SizedBox(height: 30,),
                Form(
                    key : _formKey,
                    child: Column(
                      children: [
                        Container(
                          // height: 45,
                          width: Config(context).appWidth(88),
                          // decoration: BoxDecoration(
                          //     border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          //     borderRadius: BorderRadius.circular(10)
                          // ),
                          child: TextFormField(
                            validator: (value) {
                              int res = validateName(value!);
                              if (res == 1) {
                                return "Please  fill full name";
                              }  else {
                                return null;
                              }
                            },
                            onChanged: (text) {
                            },
                            controller: nameTextController,
                            keyboardType: TextInputType.text,
                            style: TextStyle(
                                fontSize: 14
                            ),
                            textAlignVertical: TextAlignVertical.center,
                            textAlign: TextAlign.left,
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.symmetric(horizontal: 10),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color:  Color(0xffBEBAB3),
                                  ),
                                  borderRadius: BorderRadius.circular(10)
                              ),
                              hintText: "Name",
                              hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                            ),
                          ),
                        ),
                        SizedBox(height: 20,),
                        Container(
                          width: Config(context).appWidth(88),
                          child: TextFormField(
                            validator: (value) {
                              int res = validateEmail(value!);
                              if (res == 1) {
                                return "Please  fill email address";
                              } else if (res == 2) {
                                return "Please enter valid email address";
                              } else {
                                return null;
                              }
                            },
                            onChanged: (text) {

                            },
                            controller: emailTextController,
                            keyboardType: TextInputType.text,
                            style: TextStyle(
                                fontSize: 14
                            ),
                            textAlignVertical: TextAlignVertical.center,
                            textAlign: TextAlign.left,
                            decoration: InputDecoration(
                              contentPadding: EdgeInsets.symmetric(horizontal: 10),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color:  Color(0xffBEBAB3),
                                  ),
                                  borderRadius: BorderRadius.circular(10)
                              ),
                              hintText: "Email",
                              hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                            ),
                          ),
                        ),
                        SizedBox(height: 20,),
                        Container(
                          width: Config(context).appWidth(88),
                          child: TextFormField(
                            validator: (value) {
                              int res = validatePassword(value!);
                              if (res == 1) {
                                return "Please enter password";
                              } else if (res == 2) {
                                return "Please enter minimum 6 characters";
                              } else {
                                return null;
                              }
                            },
                            onChanged: (text) {

                            },
                            controller: passwordTextController,
                            keyboardType: TextInputType.text,
                            obscureText: _obscureText,
                            style: TextStyle(
                                fontSize: 14
                            ),
                            textAlignVertical: TextAlignVertical.center,
                            textAlign: TextAlign.left,
                            decoration: InputDecoration(
                                contentPadding: EdgeInsets.symmetric(horizontal: 10),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color:  Color(0xffBEBAB3),
                                    ),
                                    borderRadius: BorderRadius.circular(10)
                                ),
                              hintText: "Password",
                              hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                              suffixIcon: IconButton(
                                onPressed: () {
                                  _togglePassword();
                                },
                                icon: ImageIcon(
                                  AssetImage(_obscureText ? "assets/images/eye_hidden.png" : "assets/images/eye_show.png"),
                                ),
                              )

                            ),
                          ),
                        ),
                        SizedBox(height: 20,),
                        Container(
                          width: Config(context).appWidth(88),
                          child: TextFormField(
                            validator: (value) {
                              int res = validateConfirmPassword(value!);
                              if (res == 1) {
                                return "Please enter confirmation password";
                              } else if (res == 2) {
                                return "Please enter minimum 6 characters";
                              } else if (res == 3) {
                                return "The password is not matched.";
                              } else {
                                return null;
                              }
                            },
                            onChanged: (text) {

                            },
                            controller: confirmPasswordTextController,
                            keyboardType: TextInputType.text,
                            obscureText: _obscureTextConfirm,
                            style: TextStyle(
                                fontSize: 14
                            ),
                            textAlignVertical: TextAlignVertical.center,
                            textAlign: TextAlign.left,
                            decoration: InputDecoration(
                                contentPadding: EdgeInsets.symmetric(horizontal: 10),
                                border: OutlineInputBorder(
                                    borderSide: BorderSide(
                                      color:  Color(0xffBEBAB3),
                                    ),
                                    borderRadius: BorderRadius.circular(10)
                                ),
                              hintText: "Confirm Password",
                              hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                              suffixIcon: IconButton(
                                onPressed: () {
                                  _toggleConfirmPassword();
                                },
                                icon: ImageIcon(
                                  AssetImage(_obscureTextConfirm ? "assets/images/eye_hidden.png" : "assets/images/eye_show.png"),
                                ),
                              )

                            ),
                          ),
                        ),
                      ],
                    )
                ),
                SizedBox(height: 10,),
                // Row(
                //   mainAxisAlignment: MainAxisAlignment.center,
                //   children: [
                //     Text("Forgot Password?", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                //   ],
                // ),
                SizedBox(height: 30,),
                GestureDetector(
                  onTap: () {
                    // Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomNavigation()));
                    signupPost();
                  },
                  child: Container(
                    width: Config(context).appWidth(85),
                    height: 50,
                    decoration:  BoxDecoration(
                        color: Color(0xffFFFF00),
                        borderRadius: BorderRadius.circular(10)
                    ),
                    alignment: Alignment.center,
                    child: Center(
                      child: Text("Sign up", style: TextStyle(color: Color(0xff3C3A36) ,  fontSize: 14, fontWeight: FontWeight.w600),),
                    ),
                  ),
                ),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => LoginView()));
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Log in", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ],
                  ),
                )
              ],
            ),
          )

        ],
      ),
    );
  }
}

