import 'dart:async';
import 'dart:convert';
import 'package:fitted/view/auth/forgot_password.dart';
import 'package:fitted/widgets/custom_inkwell_btn.dart';
import 'package:http/http.dart' as http;
import 'package:fitted/controllers/auth_controller.dart';
import 'package:fitted/view/auth/signup.dart';
import 'package:fitted/view/bottom_navigation/bottom_navigation.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:fitted/utils/Configs.dart';
import 'package:google_sign_in/google_sign_in.dart';
import 'package:shared_preferences/shared_preferences.dart';

const List<String> scopes = <String>[
  'email',
  'https://www.googleapis.com/auth/contacts.readonly',
];

GoogleSignIn _googleSignIn = GoogleSignIn(
  clientId: '383609569913-enkpage221hersfjgsfv474fd6oojulo.apps.googleusercontent.com',
  // clientId: 'AIzaSyCOBmg41npSzilOekqb4SqLo-IDO6cNyFI.apps.googleusercontent.com',
  scopes: scopes,
);

class LoginView extends StatefulWidget {
  LoginView(
      {Key? key})
      : super(key: key);
  final GlobalKey<ScaffoldState> scaffoldKey = new GlobalKey<ScaffoldState>();
  @override
  State<LoginView > createState() => _LoginViewState();
}

class _LoginViewState extends State<LoginView>  {
  @override
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController emailTextController = new TextEditingController();
  TextEditingController passwordTextController = new TextEditingController();
  AuthController authController  = new AuthController();
  bool _obscureText = true;
  bool loading = false;
  GoogleSignInAccount? _currentUser;
  bool _isAuthorized = false;
  String _contactText = '';

  @override
  void initState() {
    super.initState();
    _googleSignIn.onCurrentUserChanged
        .listen((GoogleSignInAccount? account) async {
      bool isAuthorized = account != null;

      if (kIsWeb && account != null) {
        isAuthorized = await _googleSignIn.canAccessScopes(scopes);
      }

      setState(() {
        _currentUser = account;
        _isAuthorized = isAuthorized;
      });

      if (isAuthorized) {
        unawaited(_handleGetContact(account!));
      }
    });
    _googleSignIn.signInSilently();
  }

  Future<void> _handleGetContact(GoogleSignInAccount user) async {
    setState(() {
      _contactText = 'Loading contact info...';
    });

    final http.Response response = await http.get(
      Uri.parse('https://people.googleapis.com/v1/people/me/connections'
          '?requestMask.includeField=person.names'),
      headers: await user.authHeaders,
    );

    if (response.statusCode != 200) {
      setState(() {
        _contactText =
        'People API gave a ${response.statusCode} reponse. Check logs for details.';
      });

      print('People API ${response.statusCode} response: ${response.body}');
      return;
    }

    final Map<String, dynamic> data =
    json.decode(response.body) as Map<String, dynamic>;

    setState(() {
      if (data.isNotEmpty) {
        _contactText = '${data.length} contacts';
      } else {
        _contactText = 'No contacts to display.';
      }
    });
  }

  Future<void> _handleGoogleSignIn() async {
    // try {
    //   await _googleSignIn.signIn();
    // } catch (error) {
    //   print(error);
    // }

    _handleAuthorizeScopes();
  }
  GoogleSignIn _googleSignIn = GoogleSignIn(scopes: ['email']);
  // Future<void> _handleAuthorizeScopes() async {
  //   setState(() {
  //
  //   });
  //   final bool isAuthorized = await _googleSignIn.requestScopes(scopes);
  //
  //   print("HHHHHHHHHHHHHHHH");
  //   print(isAuthorized);
  //   setState(() {
  //     _isAuthorized = isAuthorized;
  //   });
  //
  //   if (isAuthorized) {
  //     unawaited(_handleGetContact(_currentUser!));
  //   }
  // }
  Future<void> _handleAuthorizeScopes() async {
    try {
      await _googleSignIn.signIn();
      // Signed in successfully, handle the user data.
      // For example, you can access the user's name and email using:
      // _googleSignIn.currentUser.displayName
      // _googleSignIn.currentUser.email
    } catch (error) {
      print('Error signing in: $error');
    }
  }
  Future<void> _signOut() {
    return _googleSignIn.disconnect();
  }

  final GoogleSignIn googleSignIn = GoogleSignIn(
    scopes: [
      'https://www.googleapis.com/auth/gmail.send'
    ],
  );

  Future signInWithGoogle(
      {required BuildContext context,
        }) async {

    await googleSignIn.signOut().then((value) async {
      final GoogleSignInAccount? googleSignInAccount =
      await googleSignIn.signIn();

      if (googleSignInAccount != null) {
        final GoogleSignInAuthentication googleSignInAuthentication =
        await googleSignInAccount.authentication;

        String deviceId = '';
        // if (authProvider.getDeviceID().isEmpty) {
        //   var uuid = const Uuid();
        //   deviceId = uuid.v4();
        //   authProvider.saveDeviceID(deviceId);
        // } else {
        //   deviceId = authProvider.getDeviceID();
        // }
        Map data = {
          "social": 'google',
          "social_id": googleSignInAuthentication.idToken.toString(),
          "email": googleSignInAccount.email.toString(),
          "username": ""//"${googleSignInAccount.name.toString()}",

        };
        print("data $data");
        var responseJson;
        var responseBack = await authController.socialLogin(data);
        responseJson = json.decode(responseBack);
        print("resssssssssssssssss${responseJson}");
        if (responseJson['code'] == 200) {
          final sharedPreferences = await SharedPreferences.getInstance();
          sharedPreferences.setString('user', responseBack);
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(backgroundColor: Colors.green,
                content:
                Text('Login Success', style: TextStyle(color: Colors.white),),
                duration: Duration(seconds: 2)),
          );
          Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomNavigation(currentTab: 0, key: widget.scaffoldKey,)));
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(
                content:
                Text('Issue has been occurred',
                  style: TextStyle(color: Colors.white),),
                duration: Duration(seconds: 2)),
          );
        }
      }

    });
  }



  int validateEmail(String emailAddress) {
    String patttern = r'^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$';
    RegExp regExp = new RegExp(patttern);
    if (emailAddress.isEmpty || emailAddress.length == 0) {
      return 1;
    } else if (!regExp.hasMatch(emailAddress)) {
      return 2;
    } else {
      return 0;
    }
  }

  int validatePassword(String pswd) {
    if (pswd.isEmpty || pswd.length == 0) {
      return 1;
    } else if (pswd != null && pswd.isNotEmpty && pswd.length <= 5) {
      return 2;
    } else {
      return 0;
    }
  }

  void _toggle() {
    setState(() {
      _obscureText = !_obscureText;
    });
  }


  void validateLoginForm(text) {
    final FormState? form = _formKey.currentState;
    if (form!.validate()) {
      print('Form is valid');
    } else {
      print('Form is invalid');
    }
  }

  Future<void> loginPost() async {
    if(_formKey.currentState!.validate()) {
      setState(() {
        loading = true;
      });
      var responseJson;
      var email = emailTextController.text;
      var password = passwordTextController.text;
      var responseBack = await authController.loginRepo(email, password);
      responseJson = json.decode(responseBack);
      if(responseJson['code'] == 200) {
        final sharedPreferences = await SharedPreferences.getInstance();
        sharedPreferences.setString('user', responseBack);
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(backgroundColor: Colors.green,
              content:
              Text('Login Success', style: TextStyle(color: Colors.white),),
              duration: Duration(seconds: 2)),
        );
        Navigator.of(context).push(MaterialPageRoute(builder: (context) => BottomNavigation(currentTab: 0, key: widget.scaffoldKey,)));
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(
              content:
              Text('Incorrect Login Credentials', style: TextStyle(color: Colors.white),),
              duration: Duration(seconds: 2)),
        );
      }
      setState(() {
        loading = false;
      });
    }
  }


  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [

          Padding(padding: EdgeInsets.only( left:  Config(context).appHeight(5),  right:  Config(context).appHeight(5)),
            child: ListView(
              children: [
                Image.asset('assets/images/logo.png', height: Config(context).appWidth(50), fit: BoxFit.fitHeight,),
                SizedBox(height: 30,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text("Log in", style: TextStyle(color: Color(0xff3C3A36) , fontSize: 24, fontWeight: FontWeight.w600),),
                    SizedBox(height: 10,),
                    // Text("Login with social networks", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    // SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        // Container(
                        //   width: Config(context).appWidth(10),
                        //   height: Config(context).appWidth(10),
                        //   decoration: BoxDecoration(
                        //     borderRadius: BorderRadius.circular(5),
                        //     color: Color(0xffBEBAB3)
                        //   ),
                        //   child: Center(
                        //     child: Image.asset('assets/images/facebook_icon.png'),
                        //   ),
                        // ),
                        // SizedBox(width: 10,),
                        // Container(
                        //   width: Config(context).appWidth(10),
                        //   height: Config(context).appWidth(10),
                        //   decoration: BoxDecoration(
                        //       borderRadius: BorderRadius.circular(5),
                        //       color: Color(0xffBEBAB3)
                        //   ),
                        //   child: Center(
                        //     child: Image.asset('assets/images/instagram_icon.png'),
                        //   ),
                        // ),
                        // SizedBox(width: 10,),
                        InkWell(
                          onTap: () {
                          //  _handleGoogleSignIn();
                            signInWithGoogle(context: context);
                          },
                          child: Container(
                            width: Config(context).appWidth(10),
                            height: Config(context).appWidth(10),
                            decoration: BoxDecoration(
                                borderRadius: BorderRadius.circular(5),
                                color: Color(0xffBEBAB3)
                            ),
                            child: Center(
                              child: Image.asset('assets/images/google_icon.png'),
                            ),
                          ),
                        ),
                        SizedBox(width: 10,),
                        // ClipRRect(
                        //   borderRadius: BorderRadius.circular(5),
                        //   child: Image.asset('assets/images/apple_icon.png', width: Config(context).appWidth(10), height: Config(context).appWidth(10),),
                        // )

                      ],
                    )
                  ],
                ),
                SizedBox(height: 30,),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Container(
                        // height: 45,
                        width: Config(context).appWidth(88),
                        // decoration: BoxDecoration(
                        //     border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                        //     borderRadius: BorderRadius.circular(10)
                        // ),
                        child: TextFormField(
                          validator: (value) {
                            int res = validateEmail(value!);
                            if (res == 1) {
                              return "Please  fill email address";
                            } else if (res == 2) {
                              return "Please enter valid email address";
                            } else {
                              return null;
                            }
                          },
                          onChanged: (text) {

                          },
                          controller: emailTextController,
                          keyboardType: TextInputType.text,
                          style: TextStyle(
                              fontSize: 14
                          ),
                          textAlignVertical: TextAlignVertical.center,
                          textAlign: TextAlign.left,
                          textInputAction: TextInputAction.next,
                          decoration: InputDecoration(
                            // border: OutlineInputBorder(
                            //   borderSide: BorderSide.none,
                            // ),
                            hintText: "Email",
                            hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                            contentPadding: EdgeInsets.symmetric(horizontal: 10),
                            border: OutlineInputBorder(
                                borderSide: BorderSide(
                                  color:  Color(0xffBEBAB3),
                                ),
                                borderRadius: BorderRadius.circular(10)
                            ),
                          ),
                        ),
                      ),
                      SizedBox(height: 20,),
                      Container(
                        // height: 45,
                        width: Config(context).appWidth(88),
                        // decoration: BoxDecoration(
                        //     border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                        //     borderRadius: BorderRadius.circular(10)
                        // ),
                        child: TextFormField(
                          validator: (value) {
                            int res = validatePassword(value!);
                            if (res == 1) {
                              return "Please enter password";
                            } else if (res == 2) {
                              return "Please enter minimum 6 characters";
                            } else {
                              return null;
                            }
                          },
                          onChanged: (text) {

                          },
                          controller: passwordTextController,
                          keyboardType: TextInputType.text,
                          obscureText: _obscureText,
                          style: TextStyle(
                              fontSize: 14
                          ),
                          textAlignVertical: TextAlignVertical.center,
                          textAlign: TextAlign.left,
                          decoration: InputDecoration(
                            hintText: "Password",
                            hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                              contentPadding: EdgeInsets.symmetric(horizontal: 10),
                              border: OutlineInputBorder(
                                  borderSide: BorderSide(
                                    color:  Color(0xffBEBAB3),
                                  ),
                                  borderRadius: BorderRadius.circular(10)
                              ),
                            suffixIcon: IconButton(
                              onPressed: () {
                                _toggle();
                              },
                              icon: ImageIcon(
                                AssetImage(_obscureText ? "assets/images/eye_hidden.png" : "assets/images/eye_show.png"),
                              ),
                            )
                          ),
                        ),
                      ),
                      SizedBox(height: 10,),
                    ],
                  ),
                ),
                SizedBox(height: 30,),
                GestureDetector(
                  onTap: ()  {
                   loginPost();
                  },
                  child: Container(
                    width: Config(context).appWidth(85),
                    height: 50,
                    decoration:  BoxDecoration(
                        color: Color(0xffFFFF00),
                        borderRadius: BorderRadius.circular(10)
                    ),
                    alignment: Alignment.center,
                    child: Center(
                      child: Text("Log in", style: TextStyle(color: Color(0xff3C3A36) ,  fontSize: 14, fontWeight: FontWeight.w600),),
                    ),
                  ),
                ),
                SizedBox(height: 10,),
                GestureDetector(
                  onTap: () {
                    Navigator.of(context).push(MaterialPageRoute(builder: (context) => SignupView()));
                  },
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Text("Sign up", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ],
                  ),
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    CustomInkWell(
                      onTap: (){
                        Navigator.push(context, MaterialPageRoute(builder: (context)=>ForgotPassword()));
                      },
                      child: Container(
                        padding: EdgeInsets.all(5),
                        child:       Text("Forgot Password?", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),

                      ),
                    )
                 ],
                ),
              ],
            ),
          ),
          loading? Align(
            alignment: Alignment.center,
            child: Image.asset(
              "assets/images/loading.gif",
              height: 60.0,
              width: 60.0,
            ),
          ) : Container(),

        ],
      ),
    );
  }


}

