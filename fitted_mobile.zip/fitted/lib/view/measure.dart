import 'dart:convert';

import 'package:fitted/controllers/api_controller.dart';
import 'package:fitted/utils/Configs.dart';
import 'package:fitted/utils/camera_screen.dart';
import 'package:fitted/utils/custome_toggle.dart';
import 'package:fitted/view/measureDetail.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Measure extends StatefulWidget {
  Measure(
      {Key? key})
      : super(key: key);

  @override
  State<Measure> createState() => _MeasureViewState();
}

class _MeasureViewState extends State<Measure>  {
  @override

  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController heightTextController = new TextEditingController();
  TextEditingController weightTextController = new TextEditingController();
  bool isSwitched = false;
  bool genderSwitched = false;
  var username = '';
  bool loading = false;

  APIController apiController = new APIController();

  void initState() {
    super.initState();
    cloudAuthAPI();
    loadUserInformation();
  }

  Future<void> cloudAuthAPI () async {
    await apiController.cloudAuthPost();
  }

  Future<void> loadUserInformation () async {
    final sharedPreferences = await SharedPreferences.getInstance();
    if(sharedPreferences.containsKey('user')){
      var user =  json.decode(sharedPreferences.getString('user')!);
      setState(()  {
        username = user['name'];
      });
    }
  }

  Future<void> nextHandle() async {
    final sharedPreferences = await SharedPreferences.getInstance();
    if(_formKey.currentState!.validate()){
      setState(() {
        loading = true;
      });
      var data = {};
      int metric = isSwitched ? 1: 0;
      int gender = genderSwitched ? 1: 0;
      data['unit'] = metric;
      data['gender'] = gender;
      data['height'] =  heightTextController.text;
      data['weight'] =  weightTextController.text;
      sharedPreferences.setString('measurement', json.encode(data));
      setState(() {
        loading = false;
      });
      Navigator.of(context).push(MaterialPageRoute(builder: (context) => MeasureDetail()));
    }

  }

  int validateHeight(String height) {
    if (height.isEmpty || height.length == 0) {
      return 1;
    }  else {
      return 0;
    }
  }

  int validateWeight(String height) {
    if (height.isEmpty || height.length == 0) {
      return 1;
    }  else {
      return 0;
    }
  }


  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(padding: EdgeInsets.only( left:  Config(context).appHeight(5),  right:  Config(context).appHeight(5)),
            child: ListView(
              children: [
                SizedBox(height: 30,),
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text(username, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 24, fontWeight: FontWeight.w600),),
                    SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("metric", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                        SizedBox(width: 5),
                        CustomToggleButton(
                          activeImage: 'assets/images/toggle_active.png',
                          inactiveImage: 'assets/images/toggle_inactive.png',
                        ),
                        SizedBox(width: 5),
                        Text("imperial", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),

                      ],
                    ),
                    SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("male", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                        SizedBox(width: 5),
                        CustomToggleButton(
                          activeImage: 'assets/images/toggle_active.png',
                          inactiveImage: 'assets/images/toggle_inactive.png',
                        ),
                        SizedBox(width: 5),
                        Text("female", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),

                      ],
                    )
                  ],
                ),
                SizedBox(height: 30,),
                Form(
                  key: _formKey,
                  child: Column(
                    children: [
                      Container(
                        height: 45,
                        width: Config(context).appWidth(88),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                            borderRadius: BorderRadius.circular(10)
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: TextFormField(
                          validator: (value) {
                            int res = validateHeight(value!);
                            if (res == 1) {
                              return "Please fill height";
                            } else {
                              return null;
                            }
                          },
                          onChanged: (text) {

                          },
                          controller: heightTextController,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                              fontSize: 14
                          ),
                          textAlignVertical: TextAlignVertical.center,
                          textAlign: TextAlign.left,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                            ),
                            hintText: "Height(cm/in)",
                            hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ),
                      SizedBox(height: 20,),
                      Container(
                        height: 45,
                        width: Config(context).appWidth(88),
                        decoration: BoxDecoration(
                            border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                            borderRadius: BorderRadius.circular(10)
                        ),
                        padding: EdgeInsets.symmetric(horizontal: 10),
                        child: TextFormField(
                          validator: (value) {
                            int res = validateWeight(value!);
                            if (res == 1) {
                              return "Please fill weight";
                            } else {
                              return null;
                            }
                          },
                          onChanged: (text) {

                          },
                          controller: weightTextController,
                          keyboardType: TextInputType.number,
                          style: TextStyle(
                              fontSize: 14
                          ),
                          textAlignVertical: TextAlignVertical.center,
                          textAlign: TextAlign.left,
                          decoration: InputDecoration(
                            border: OutlineInputBorder(
                              borderSide: BorderSide.none,
                            ),
                            hintText: "Weight(kg/lb)",
                            hintStyle: TextStyle(color: Color(0xffE2E2E2), fontSize: 14),
                            contentPadding: EdgeInsets.zero,
                          ),
                        ),
                      ),
                    ],
                  ),
                ),

                SizedBox(height: 20,),
                GestureDetector(
                  onTap: () {
                    nextHandle();

                  },
                  child: Container(
                    width: Config(context).appWidth(85),
                    height: 50,
                    decoration:  BoxDecoration(
                        color: Color(0xffFFFF00),
                        borderRadius: BorderRadius.circular(10)
                    ),
                    alignment: Alignment.center,
                    child: Center(
                      child: Text("Next", style: TextStyle(color: Color(0xff3C3A36) ,  fontSize: 14, fontWeight: FontWeight.w600),),
                    ),
                  ),
                ),

              ],
            ),
          ),
          loading? Align(
            alignment: Alignment.center,
            child: Image.asset(
              "assets/images/loading.gif",
              height: 60.0,
              width: 60.0,
            ),
          ) : Container(),
        ],
      ),
    );
  }




}


//

