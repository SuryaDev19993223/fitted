
import 'dart:io';

import 'package:fitted/utils/Configs.dart';
import 'package:fitted/widgets/colors.dart';
import 'package:fitted/widgets/custom_inkwell_btn.dart';
import 'package:fitted/widgets/custom_text.dart';
import 'package:flutter/material.dart';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:path_provider/path_provider.dart';
import 'package:flutter/services.dart';
import 'package:pdf/widgets.dart' as pw;
import 'package:csv/csv.dart';
import 'dart:io'as io;
import 'package:path_provider/path_provider.dart';
import 'package:permission_handler/permission_handler.dart' as perm;
import 'package:permission_handler/permission_handler.dart';

class MeasurementExport extends StatefulWidget {
  String neck ;
  String wrist ;
  String arm ;
  String inseam ;
  String back ;
  String shoulder ;
  String chest ;
  String bust ;
  String stomach ;
  String thigh ;
  String ankle ;
  String knee ;

  MeasurementExport(
      {Key? key,this.neck="",
        this.wrist="",
        this.arm="",
        this.inseam="",
        this.back="",
        this.shoulder="",
        this.chest="",
        this.bust="",
        this.stomach="",
        this.thigh="",
        this.ankle="",
        this.knee="",

      })
      : super(key: key);

  @override
  State<MeasurementExport> createState() => _MeasurementExportViewState();
}

class _MeasurementExportViewState extends State<MeasurementExport>  {
  // Future<void> requestStoragePermission() async {
  //   final permissionStatus = await perm.Permission.storage.status;
  //   if (permissionStatus.isDenied) {
  //     // Here just ask for the permission for the first time
  //     await perm.Permission.storage.request();
  //
  //     // I noticed that sometimes popup won't show after user press deny
  //     // so I do the check once again but now go straight to appSettings
  //     if (permissionStatus.isDenied) {
  //       await perm.openAppSettings();
  //     }
  //   } else if (permissionStatus.isPermanentlyDenied) {
  //     // Here open app settings for user to manually enable permission in case
  //     // where permission was permanently denied
  //     await perm.openAppSettings();
  //   } else {
  //     // Do stuff that require permission here
  //   }
  // }
  // initState(){
  //   super.initState();
  //   requestStoragePermission();
  // }
  // Future<void> downloadPDF(String url) async {
  //   setState(() {
  //
  //   });
  //   final response = await http.get(Uri.parse(url));
  //   final documentDirectory = await getApplicationDocumentsDirectory();
  //   SnackBar(content: CustomText(title: "PDF has been downloaded",color: whiteColor,),
  //     backgroundColor: redColor,
  //   );
  //   final file = io.File('${documentDirectory.path}/your_pdf_file.pdf');
  //   await file.writeAsBytes(response.bodyBytes);
  // }
  //
  // Future<void> downloadCSV(String url) async {
  //   setState(() {
  //
  //   });
  //   final response = await http.get(Uri.parse(url));
  //   final documentDirectory = await getApplicationDocumentsDirectory();
  //   SnackBar(content: CustomText(title: "CSV has been downloaded",color: whiteColor,),
  //     backgroundColor: redColor,
  //   );
  //   final file = io.File('${documentDirectory.path}/your_csv_file.csv');
  //   await file.writeAsString(response.body);
  // }
  //
  //
  // Future<void> downloadImage(String url) async {
  //   setState(() {
  //
  //   });
  //   final response = await http.get(Uri.parse(url));
  //   final documentDirectory = await getApplicationDocumentsDirectory();
  //   SnackBar(content: CustomText(title: "Image has been downloaded",color: whiteColor,),
  //     backgroundColor: redColor,
  //   );
  //   final file = io.File('${documentDirectory.path}/your_image.png');
  //   await file.writeAsBytes(response.bodyBytes);
  //
  // }



  Future<void> _exportToPdf(File? file) async {
    final pdf = pw.Document();
    pdf.addPage(
      pw.Page(
        build: (pw.Context context) {
          return pw.Center(
            child: pw.Column(
              children: [
                _buildPdfText('Ankle', widget.ankle),
                _buildPdfText('Knee', widget.knee),
                _buildPdfText('Thigh', widget.thigh),
                _buildPdfText('Stomach', widget.stomach),
                _buildPdfText('Bust', widget.bust),
                _buildPdfText('Chest', widget.chest),
                _buildPdfText('Shoulder', widget.shoulder),
                _buildPdfText('Back', widget.back),
                _buildPdfText('Inseam', widget.inseam),
                _buildPdfText('Arm', widget.arm),
                _buildPdfText('Wrist', widget.wrist),
                _buildPdfText('Neck', widget.neck),
              ],
            ),
          );
        },
      ),
    );
    await file?.writeAsBytes(await pdf.save());
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('PDF exported successfully'),
      ),
    );
  }
  pw.Widget _buildPdfText(String label, String value) {
    return pw.Column(
      crossAxisAlignment: pw.CrossAxisAlignment.start,
      children: [
        pw.Text('$label:'),
        pw.Text(value),
        pw.SizedBox(height: 10),
      ],
    );
  }



    Future<bool> saveFile(String isType) async {


    Directory? directory;
    try {
      if (Platform.isAndroid) {
        if (await _requestPermissions(Permission.manageExternalStorage) ||
            await _requestPermissions(Permission.storage)) {
          directory = await getExternalStorageDirectory();
          String newPath = "";
          List<String> folders = directory!.path.split('/');
          for (int x = 1; x < folders.length; x++) {
            String folder = folders[x];
            if (folder != "Android") {
              newPath += "/$folder";
            } else {
              break;
            }
          }
          newPath = "$newPath/Download";
          directory = Directory(newPath);
        } else {
          if (await _requestPermissions(Permission.photos)) {
            directory = await getTemporaryDirectory();
          } else {
            return false;
          }
        }
        if (!await directory.exists()) {
          await directory.create(recursive: true);
        }
        if (await directory.exists()) {
          File file = File(directory.path + "/data.pdf");
          isType=="pdf"?_exportToPdf(file):_exportToCsv(file);
          print("start Downloading2");

        }
      }
    } catch (e) {
      return false;
    }
    return false;
  }

  Future<bool> _requestPermissions(Permission permission) async {
    if (await permission.isGranted) {
      return true;
    } else {
      var result = await permission.request();
      if (result == PermissionStatus.granted) {
        return true;
      } else {
        return false;
      }
    }
  }
  void _exportToCsv(File? file) async {
    List<List<dynamic>> csvData = [
      ['Ankle', 'Knee', 'Thigh', 'Stomach', 'Bust', 'Chest', 'Shoulder', 'Back', 'Inseam', 'Arm', 'Wrist', 'Neck'],
      [widget.ankle,widget.knee, widget.thigh, widget.stomach, widget.bust, widget.chest, widget.shoulder, widget.back, widget.inseam, widget.arm, widget.wrist, widget.neck],
    ];

    String csv = const ListToCsvConverter().convert(csvData);
    await file?.writeAsString(csv);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text('CSV exported successfully'),
      ),
    );
  }
  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(padding: EdgeInsets.only( left:  Config(context).appHeight(5),  right:  Config(context).appHeight(5)),
            child: ListView(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        GestureDetector(
                          onTap: () {
                            Navigator.pop(context);
                          },
                          child: Image.asset('assets/images/back_icon.png'),
                        ),
                        Text("Export ", style: TextStyle(color: Color(0xff3C3A36) , fontSize: 24, fontWeight: FontWeight.w600),),
                        SizedBox(width: 10,)
                      ],
                    ),
                    SizedBox(height: 30,),
                    CustomInkWell(
                      onTap: (){
                        saveFile("pdf");
                      },
                      child:
                     Row(
                       mainAxisAlignment: MainAxisAlignment.spaceBetween,
                       children: [
                         Image.asset('assets/images/pdf_icon.png', width: Config(context).appWidth(30),),
                         Container(
                           width: Config(context).appWidth(50),
                           child: Text("Download PDF", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 16, fontWeight: FontWeight.w400),),
                         ),
                       ],
                     )),
                    CustomInkWell(
                      onTap: (){
                        saveFile("csv");
                      },
                      child:
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Image.asset('assets/images/csv_icon.png', width: Config(context).appWidth(30),),
                        Container(
                          width: Config(context).appWidth(50),
                          child: Text("Download CSV", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 16, fontWeight: FontWeight.w400),),
                        ),
                      ],
                    )),
                 CustomInkWell(
                   onTap: (){
                     saveFile("image");
                   },
                   child:     Row(
                     mainAxisAlignment: MainAxisAlignment.spaceBetween,
                     children: [
                       Image.asset('assets/images/download_icon.png', width: Config(context).appWidth(30),),
                       Container(
                         width: Config(context).appWidth(50),
                         child: Text("Download IMG", textAlign: TextAlign.left, style: TextStyle(color: Color(0xff3C3A36) , fontSize: 16, fontWeight: FontWeight.w400),),
                       ),
                     ],
                   ),
                 )

                  ],
                ),
                


              ],
            ),
          )
        ],
      ),
    );
  }



}

