import 'dart:convert';

import 'package:fitted/controllers/api_controller.dart';
import 'package:fitted/utils/Configs.dart';
import 'package:fitted/utils/custome_toggle.dart';
import 'package:fitted/view/measurementExport.dart';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Measurement extends StatefulWidget {
  Measurement(
      {Key? key})
      : super(key: key);

  @override
  State<Measurement > createState() => _MeasureViewState();
}

class _MeasureViewState extends State<Measurement>  {
  @override
  bool loading = false;
  String neck ="";
  String wrist ="";
  String arm ="";
  String inseam ="";
  String back ="";
  String shoulder ="";
  String chest ="";
  String bust ="";
  String stomach ="";
  String thigh ="";
  String ankle ="";
  String knee ="";

  void initState() {
    super.initState();
    loadMeasureData();
  }

  Future<void> loadMeasureData() async {

    final sharedPreferences = await SharedPreferences.getInstance();
    if(sharedPreferences.containsKey('calculatedMeasure')){
      setState(() {
        loading = true;
      });
      var measureList =  json.decode(sharedPreferences.getString('calculatedMeasure')!);
      setState(()  {
        for(var item in measureList) {
          if(item['sizeName'].toString().toLowerCase().contains('neck')) {
            neck = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('wrist')) {
            wrist = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('arm')) {
            arm = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('inseam')) {
            inseam = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('back')) {
            back = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('shoulder')) {
            shoulder = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('chest')) {
            chest = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('bust')) {
            bust = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('waist')) {
            stomach = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('thigh')) {
            thigh = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('ankle')) {
            ankle = item['sizeCmVal'].toString();
          }
          if(item['sizeName'].toString().toLowerCase().contains('knee')) {
            knee = item['sizeCmVal'].toString();
          }
        }

        loading = false;
      });
    }
  }

  Widget build(BuildContext context) {
    return Scaffold(
      body: Stack(
        children: [
          Padding(padding: EdgeInsets.only( left:  Config(context).appHeight(5),  right:  Config(context).appHeight(5)),
            child: ListView(
              children: [
                Column(
                  crossAxisAlignment: CrossAxisAlignment.center,
                  children: [
                    Text("Measurements", style: TextStyle(color: Color(0xff3C3A36) , fontSize: 24, fontWeight: FontWeight.w600),),
                    SizedBox(height: 10,),
                    GestureDetector(
                      onTap: () {
                        Navigator.of(context).push(MaterialPageRoute(builder: (context) => MeasurementExport(
                          ankle:ankle,
                          knee:knee,
                          thigh:thigh,
                          stomach:stomach,
                          bust:bust,
                          chest:chest,
                          shoulder:shoulder,
                          back: back,
                          inseam:inseam,
                          arm:arm,
                          wrist:wrist,
                          neck: neck,
                        )));
                      },
                      child: Container(
                        width: Config(context).appWidth(85),
                        height: 50,
                        decoration:  BoxDecoration(
                            color: Color(0xffFFFF00),
                            borderRadius: BorderRadius.circular(10)
                        ),
                        alignment: Alignment.center,
                        child: Center(
                          child: Text("Export", style: TextStyle(color: Color(0xff3C3A36) ,  fontSize: 14, fontWeight: FontWeight.w600),),
                        ),
                      ),
                    ),
                    SizedBox(height: 10,),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text("cm", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                        SizedBox(width: 5),
                        CustomToggleButton(
                          activeImage: 'assets/images/toggle_active.png',
                          inactiveImage: 'assets/images/toggle_inactive.png',
                        ),
                        SizedBox(width: 5),
                        Text("inches", style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),

                      ],
                    ),

                  ],
                ),
                SizedBox(height: 30,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Neck", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(neck, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Wrist", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(wrist, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Arm", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(arm, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Inseam", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(inseam, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Back", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(back, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Shoulder", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(shoulder, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Chest", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(chest, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Bust", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(bust, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Stomach", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(stomach, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Thigh", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(thigh, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Ankle", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(ankle, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text("Knee", style: TextStyle(color: Colors.black , fontSize: 14, fontWeight: FontWeight.w500),),
                    Container(
                      width: Config(context).appWidth(60),
                      decoration: BoxDecoration(
                          border: Border.all(width: 0.8 , color: Color(0xffBEBAB3) ),
                          borderRadius: BorderRadius.circular(10)
                      ),
                      padding: EdgeInsets.symmetric(horizontal: 10, vertical: 15),
                      child: Text(knee, textAlign: TextAlign.left, style: TextStyle(color: Color(0xff78746D) , fontSize: 14, fontWeight: FontWeight.w400),),
                    ),
                  ],
                ),
                SizedBox(height: 10,),

              ],
            ),
          ),
          loading? Align(
            alignment: Alignment.center,
            child: Image.asset(
              "assets/images/loading.gif",
              height: 60.0,
              width: 60.0,
            ),
          ) : Container(),
        ],
      ),
    );
  }




}


//

