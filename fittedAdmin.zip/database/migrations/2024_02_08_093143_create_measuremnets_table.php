<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('measurements', function (Blueprint $table) {
            $table->id();
            $table->unsignedBigInteger('user_id');
            $table->boolean('gender')->default(true);
            $table->boolean('main_unit')->default(true);
            $table->string('height')->nullable();
            $table->string('weight')->nullable();
            $table->boolean('sub_unit')->default(true);
            $table->string('neck')->nullable();
            $table->string('wrist')->nullable();
            $table->string('armt')->nullable();
            $table->string('inseam')->nullable();
            $table->string('back')->nullable();
            $table->string('shoulder')->nullable();
            $table->string('chest')->nullable();
            $table->string('bust')->nullable();
            $table->string('stomach')->nullable();
            $table->string('thigh')->nullable();
            $table->string('ankle')->nullable();
            $table->string('knee')->nullable();
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('meausrements');
    }
};
