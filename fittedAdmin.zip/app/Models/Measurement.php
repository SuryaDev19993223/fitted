<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Measurement extends Model
{
    use HasFactory;

    protected $table = 'measurements';

    protected $fillable = [
        'user_id',
        'gender',
        'main_unit',
        'weight',
        'height',
        'sub_unit',
        'neck',
        'wrist',
        'arm',
        'inseam',
        'back',
        'shoulder',
        'chest',
        'bust',
        'stomach',
        'thigh',
        'ankle',
        'knee',
    ];
}
