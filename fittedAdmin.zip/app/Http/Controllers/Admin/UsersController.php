<?php

namespace App\Http\Controllers\Admin;

use App\Models\User;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use App\Http\Requests\UsersRequest;
use Illuminate\Support\Facades\Hash;

/**
 * Users management class
 * @author Alexandre Unruh <alexandre@unruh.com.br>
 */
class UsersController extends Controller
{
  /**
   * Display a listing of the resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function index()
  {
    $users = User::all();
    return view('admin.users.index', ['users' => $users]);
  }

  /**
   * Show the form for creating a new resource.
   *
   * @return \Illuminate\Http\Response
   */
  public function create()
  {
    $data = User::all();
    return view('admin.users.create', $data);
  }

  /**
   * Store a newly created resource in storage.
   *
   * @param  App\Http\Requests\UsersRequest $request
   * @return \Illuminate\Http\Response
   */
  public function store(Request $request)
  {
    $user = new User();
    if(isset($request->name)){
      $user->name = $request->name;
    }
    if(isset($request->email)){
      $user->email = $request->email;
      $user->username = $request->email;
    }
    if(isset($request->password)){
      $user->password =  Hash::make( $request->password );
    }
    $user->role = 2;
    $user->save();
    return redirect()->route('users')->with('success', 'User registered successfully!');
  }

  /**
   * Show the form for editing the specified resource.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function edit(User $user)
  {
    $data['user'] = $user;
    return view('admin.users.edit', $data);
  }

  /**
   * Update the specified resource in storage.
   *
   * @param UsersRequest $request
   * @param User $user
   * @return \Illuminate\Http\Response
   */
  public function update(Request $request, User $user)
  {
    if(isset($request->name)){
      $user->name = $request->name;
    }
    if(isset($request->email)){
      $user->email = $request->email;
    }
    if(isset($request->password)){
      $user->password =  Hash::make( $request->password );
    }
    $user->save();
    return redirect()->route('users')->with('message', 'Registration updated successfully!');
  }

  /**
   * Remove the specified resource from storage.
   *
   * @param  int  $id
   * @return \Illuminate\Http\Response
   */
  public function destroy($id)
  {
    // if (auth()->user()->id == $id) {
    //   return redirect()->back()->with('warning', 'You cannot delete your own user');
    // }

    $user = User::find($id);
    $user->delete();
    return redirect()->route('users')->with('success', 'deleted successfully!');
  }
}
