<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Route;
use Illuminate\Support\Facades\Validator;
use Illuminate\Support\Carbon;
use App\Models\User;

class AuthController extends Controller
{
    //

    public function register(Request $request) {
        $rules= [
            'name' => 'required',
            'email' => 'required|unique:users',
            'password' => 'required',
            'role' => 'required',
        ];

        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        } else {
            $user = new User();
            $user->name = $request->name;
            $user->username = $request->email;
            $user->email = $request->email;
            $user->role = $request->role;
            $user->password = Hash::make( $request->password );
            $user->save();
            return response()->json($user, 200);
        }
    }

    public function login(Request $request) {
        $rules= [
            'email' => 'required',
            'password' => 'required'
        ];
        $validator = Validator::make($request->all(), $rules);
        if ($validator->fails()) {
            return response()->json($validator->messages(), 422);
        } else {
            $user = User::where('email', $request->email)->first();
            if(isset($user)) {
                if ( Auth::attempt ( array('email' => $request->email, 'password' => $request->password) ) ){
                    $user = $request->user();
                    $user->tokens->each(function($token, $key) {
                        $token->delete();
                    });

                    $tokenResult = $user->createToken('Personal Access Token');
                    $token = $tokenResult->token;
                    if ($request->remember_me)
                        $token->expires_at = Carbon::now()->addWeeks(1);
                    $token->save();
                    $user['access_token'] = $tokenResult->accessToken;
                    $user['token_type'] =  'Bearer';

                    return response()->json($user, 200);

                } else {
                    return response()->json([
                        'message' => 'Password is incorrect.'
                    ], 401);
                }
            } else {
                return response()->json([
                    'message' => 'Email is incorrect.'
                ], 404);
            }
        }
    }

    public function getUser($id) {
        $user = User::find($id);
        return response()->json($user, 200);
    }

    public function logout($id) {
        $user = User::find($id);
        Auth::user()->token()->delete();
        
        // Auth::user()->token()->revoke();
        return response()->json([
            'message' => 'Successfully logged out'
        ]);
    }

}
