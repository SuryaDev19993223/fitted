<?php

namespace App\Http\Controllers\API;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use App\Models\Measurement;

class MeasurementController extends Controller
{
    //
    public function saveMeasurement(Request $request) {
        $measurement = Measurement::where('user_id', $request->user_id)->first();
        if(isset($measurement)) {
            $measurement->gender = $request->gender;
            $measurement->main_unit = $request->main_unit;
            $measurement->weight = $request->weight;
            $measurement->height = $request->height;
            $measurement->sub_unit = $request->sub_unit;
            $measurement->neck = $request->neck;
            $measurement->wrist = $request->wrist;
            $measurement->arm = $request->arm;
            $measurement->inseam = $request->inseam;
            $measurement->back = $request->back;
            $measurement->shoulder = $request->shoulder;
            $measurement->chest = $request->chest;
            $measurement->bust = $request->bust;
            $measurement->stomach = $request->stomach;
            $measurement->thigh = $request->thigh;
            $measurement->ankle = $request->ankle;
            $measurement->knee = $request->knee;
            $measurement->save();
            return response()->json($measurement, 200);
        } else {
            $measurements = new Measurement();
            $measurements->user_id = $request->user_id;
            $measurements->gender = $request->gender;
            $measurements->main_unit = $request->main_unit;
            $measurements->weight = $request->weight;
            $measurements->height = $request->height;
            $measurements->sub_unit = $request->sub_unit;
            $measurements->neck = $request->neck;
            $measurements->wrist = $request->wrist;
            $measurements->arm = $request->arm;
            $measurements->inseam = $request->inseam;
            $measurements->back = $request->back;
            $measurements->shoulder = $request->shoulder;
            $measurements->chest = $request->chest;
            $measurements->bust = $request->bust;
            $measurements->stomach = $request->stomach;
            $measurements->thigh = $request->thigh;
            $measurements->ankle = $request->ankle;
            $measurements->knee = $request->knee;
            $measurements->save();
            return response()->json($measurements, 200);
        }
        
        
    }
}
